class TargetCell {
  final String id;
  final String name;
  final double latitude;
  final double longitude;
  final String belt;
  final String type;
  final String source;
  final String sourceGroup;
  final String status;
  final String note;
  final Map<String, String> gates;
  final Map<String, double> scores;
  final Map<String, dynamic> spectral;
  final double magneticRisk;
  final double maxValidRadiusM;
  final String coordinateStatus;

  const TargetCell({
    required this.id,
    required this.name,
    required this.latitude,
    required this.longitude,
    required this.belt,
    required this.type,
    required this.source,
    required this.sourceGroup,
    required this.status,
    required this.note,
    required this.gates,
    required this.scores,
    required this.spectral,
    required this.magneticRisk,
    required this.maxValidRadiusM,
    required this.coordinateStatus,
  });

  factory TargetCell.fromJson(Map<String, dynamic> json) {
    Map<String, double> parseDoubleMap(Map<String, dynamic> source) {
      return source.map((key, value) => MapEntry(key, (value as num).toDouble()));
    }

    return TargetCell(
      id: '${json['id']}',
      name: '${json['name']}',
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      belt: '${json['belt']}',
      type: '${json['type']}',
      source: '${json['source']}',
      sourceGroup: '${json['source_group']}',
      status: '${json['status']}',
      note: '${json['note']}',
      gates: (json['gates'] as Map<String, dynamic>).map((k, v) => MapEntry(k, '$v')),
      scores: parseDoubleMap(json['scores'] as Map<String, dynamic>),
      spectral: (json['spectral'] as Map<String, dynamic>),
      magneticRisk: (json['magnetic_risk'] as num).toDouble(),
      maxValidRadiusM: (json['max_valid_radius_m'] as num).toDouble(),
      coordinateStatus: '${json['coordinate_status']}',
    );
  }
}
