class MapLayer {
  final String id;
  final String name;
  final String type;
  final String source;
  final bool enabled;
  final int featureCount;
  final String content;
  final DateTime createdAt;

  const MapLayer({
    required this.id,
    required this.name,
    required this.type,
    required this.source,
    required this.enabled,
    required this.featureCount,
    required this.content,
    required this.createdAt,
  });

  MapLayer copyWith({String? id, String? name, String? type, String? source, bool? enabled, int? featureCount, String? content, DateTime? createdAt}) {
    return MapLayer(
      id: id ?? this.id,
      name: name ?? this.name,
      type: type ?? this.type,
      source: source ?? this.source,
      enabled: enabled ?? this.enabled,
      featureCount: featureCount ?? this.featureCount,
      content: content ?? this.content,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type,
        'source': source,
        'enabled': enabled,
        'feature_count': featureCount,
        'content': content,
        'created_at': createdAt.toIso8601String(),
      };

  factory MapLayer.fromJson(Map<String, dynamic> json) => MapLayer(
        id: '${json['id']}',
        name: '${json['name']}',
        type: '${json['type']}',
        source: '${json['source']}',
        enabled: json['enabled'] == true,
        featureCount: (json['feature_count'] as num?)?.toInt() ?? 0,
        content: '${json['content'] ?? ''}',
        createdAt: DateTime.tryParse('${json['created_at']}') ?? DateTime.now(),
      );
}
