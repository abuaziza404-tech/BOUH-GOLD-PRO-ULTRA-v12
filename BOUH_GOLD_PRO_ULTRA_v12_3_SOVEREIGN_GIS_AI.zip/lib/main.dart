import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'data/datasources/local_pack_datasource.dart';
import 'data/repositories/analysis_repository.dart';
import 'data/repositories/workspace_repository.dart';
import 'presentation/controllers/app_controller.dart';
import 'presentation/screens/auth_gate_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BouhGoldProUltraApp());
}

class BouhGoldProUltraApp extends StatelessWidget {
  const BouhGoldProUltraApp({super.key});

  @override
  Widget build(BuildContext context) {
    final analysisRepository = AnalysisRepository(LocalPackDataSource());
    final workspaceRepository = WorkspaceRepository();
    return ChangeNotifierProvider(
      create: (_) => AppController(
        analysisRepository: analysisRepository,
        workspaceRepository: workspaceRepository,
      )..bootstrap(),
      child: MaterialApp(
        title: 'بوح التضاريس',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF050806),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFFFFD700),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
        ),
        home: const Directionality(
          textDirection: TextDirection.rtl,
          child: AuthGateScreen(),
        ),
      ),
    );
  }
}
