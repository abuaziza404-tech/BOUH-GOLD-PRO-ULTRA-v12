import '../domain/models/gpz_recommendation.dart';
import '../domain/models/spectral_indices.dart';

class GpzEngine {
  GpzRecommendation recommend({required double magneticRisk, required SpectralIndices spectral}) {
    final quartzHigh = spectral.quartzIndex != null && spectral.quartzIndex! >= 1.25;

    if (magneticRisk > 0.75) {
      return const GpzRecommendation(
        groundType: 'Severe/Difficult',
        goldMode: 'High Yield',
        sensitivity: '8–11',
        audioSmoothing: 'Low/On',
        swingStrategy: 'Slow Swing + توازن أرضي متكرر',
        reason: 'خطر مغناطيسي مرتفع؛ الأولوية لعزل الضوضاء وليس أقصى عمق.',
      );
    }

    if (magneticRisk < 0.45 && quartzHigh) {
      return const GpzRecommendation(
        groundType: 'Normal',
        goldMode: 'General/Deep',
        sensitivity: '12–16',
        audioSmoothing: 'Off',
        swingStrategy: 'تداخل مشي ضيق وبطيء لتعظيم العمق',
        reason: 'أرض منخفضة الضوضاء مع كوارتز مرتفع؛ يمكن رفع العمق.',
      );
    }

    return const GpzRecommendation(
      groundType: 'Difficult',
      goldMode: 'High Yield أو General بعد اختبار قصير',
      sensitivity: '10–13',
      audioSmoothing: 'Low',
      swingStrategy: 'شبكة اختبار قصيرة 20×20م قبل التوسع',
      reason: 'حالة مختلطة أو SWIR/Quartz غير مؤكد؛ لا ترفع الحساسية قبل اختبار الضوضاء.',
    );
  }
}
