import 'dart:math' as math;

class SimilarityResult {
  final String id;
  final String name;
  final double euclideanDistance;
  final double cosineSimilarity;
  final String label;

  const SimilarityResult({required this.id, required this.name, required this.euclideanDistance, required this.cosineSimilarity, required this.label});
}

class SimilarityEngine {
  double euclidean(List<double> a, List<double> b) {
    var sum = 0.0;
    for (var i = 0; i < a.length; i++) {
      final d = a[i] - b[i];
      sum += d * d;
    }
    return math.sqrt(sum);
  }

  double cosine(List<double> a, List<double> b) {
    var dot = 0.0;
    var na = 0.0;
    var nb = 0.0;
    for (var i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      na += a[i] * a[i];
      nb += b[i] * b[i];
    }
    if (na == 0 || nb == 0) return 0.0;
    return dot / (math.sqrt(na) * math.sqrt(nb));
  }
}
