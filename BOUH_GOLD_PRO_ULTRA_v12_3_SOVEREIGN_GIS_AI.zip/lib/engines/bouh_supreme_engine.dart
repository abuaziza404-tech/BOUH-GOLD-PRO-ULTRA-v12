import '../domain/models/analysis_result.dart';
import '../domain/models/gpz_recommendation.dart';
import '../domain/models/spectral_indices.dart';
import '../domain/models/target_cell.dart';

class BouhSupremeEngine {
  AnalysisResult analyze({
    required TargetCell? cell,
    required double tappedLatitude,
    required double tappedLongitude,
    required double distanceMeters,
    required SpectralIndices spectral,
    required GpzRecommendation gpz,
  }) {
    if (cell == null) {
      return AnalysisResult(
        cell: null,
        tappedLatitude: tappedLatitude,
        tappedLongitude: tappedLongitude,
        distanceMeters: distanceMeters,
        outsidePack: true,
        decision: 'Outside Pack',
        title: 'خارج نطاق الحزمة',
        explanation: 'لا توجد خلية Region Pack قريبة كفاية. لا يتم إعطاء Candidate أو Target-B خارج نطاق البيانات.',
        ipi: 0,
        pScore: 0,
        triggeredGates: const ['OUTSIDE_PACK'],
        spectral: spectral,
        gpz: gpz,
      );
    }

    if (distanceMeters > cell.maxValidRadiusM) {
      return AnalysisResult(
        cell: cell,
        tappedLatitude: tappedLatitude,
        tappedLongitude: tappedLongitude,
        distanceMeters: distanceMeters,
        outsidePack: true,
        decision: 'Outside Pack',
        title: 'خارج نطاق الخلية الموثوقة',
        explanation: 'أقرب خلية بعيدة أكثر من ${cell.maxValidRadiusM.toStringAsFixed(0)}م؛ تم منع التصنيف حتى لا تتكرر قراءة 32 كم الخاطئة.',
        ipi: cell.scores['IPI'] ?? 0,
        pScore: cell.scores['PScore'] ?? 0,
        triggeredGates: const ['DISTANCE_GUARD'],
        spectral: spectral,
        gpz: gpz,
      );
    }

    final gates = cell.gates;
    final structure = gates['structure'] ?? 'Unknown';
    final pattern = gates['pattern'] ?? 'Unknown';
    final swir = gates['swir_clay'] ?? 'Unknown';
    final quartz = gates['quartz_carrier'] ?? 'Unknown';
    final field = gates['field_evidence'] ?? 'No';
    final triggered = <String>[];

    bool isNo(String value) => value.toLowerCase() == 'no';
    bool isUnknown(String value) {
      final v = value.toLowerCase();
      return v == 'unknown' || v == 'pending' || v == 'null' || v.trim().isEmpty;
    }
    bool isYes(String value) => value.toLowerCase() == 'yes' || value.toLowerCase() == 'partial';

    if (isNo(structure)) triggered.add('G01_NO_STRUCTURE');
    if (isNo(pattern)) triggered.add('G02_NO_PATTERN');
    if (isNo(swir) || isUnknown(swir) || !spectral.hasRawBands) triggered.add('G04_NO_SWIR_CLAY');
    if (isYes(quartz) && isNo(structure)) triggered.add('G05_QUARTZ_ONLY_NO_STRUCTURE');

    final ipi = cell.scores['IPI'] ?? 0;
    final pScore = cell.scores['PScore'] ?? 0;

    if (triggered.contains('G01_NO_STRUCTURE')) {
      return _result(cell, tappedLatitude, tappedLongitude, distanceMeters, 'Reject', 'رفض صارم', 'لا توجد بنية مؤكدة؛ No Structure = Reject.', ipi, pScore, triggered, spectral, gpz);
    }

    if (triggered.contains('G02_NO_PATTERN')) {
      return _result(cell, tappedLatitude, tappedLongitude, distanceMeters, 'Reject', 'رفض نمطي', 'لا يوجد Pattern/Trap مؤكد؛ لا حفر ولا ترقية.', ipi, pScore, triggered, spectral, gpz);
    }

    if (triggered.contains('G04_NO_SWIR_CLAY')) {
      return _result(cell, tappedLatitude, tappedLongitude, distanceMeters, 'HOLD', 'تعليق محافظ', 'النقطة من بيانات المشروع الحقيقية، لكن SWIR/Clay غير مؤكد. لا Candidate ولا Target-B قبل الباندات أو شاهد ميداني.', ipi, pScore, triggered, spectral, gpz);
    }

    final active = [structure, pattern, swir, quartz, field].where(isYes).length;
    if (active < 3) {
      triggered.add('ACTIVE_INDICATORS_LT_3');
      return _result(cell, tappedLatitude, tappedLongitude, distanceMeters, 'Low HOLD', 'خفض تلقائي', 'أقل من 3 مؤشرات نشطة ضمن الخلية؛ تم التخفيض.', ipi, pScore, triggered, spectral, gpz);
    }

    if (ipi >= 85 && isYes(field)) {
      return _result(cell, tappedLatitude, tappedLongitude, distanceMeters, 'Target-B Elite', 'Target-B Elite', 'استوفى البنية والنمط والتحول والشاهد؛ يبقى assay/QAQC شرط الحقيقة الاقتصادية.', ipi, pScore, triggered, spectral, gpz);
    }
    if (ipi >= 70) {
      return _result(cell, tappedLatitude, tappedLongitude, distanceMeters, 'Candidate', 'مرشح قوي', 'مرشح للتحقق الميداني وليس إثباتًا اقتصاديًا.', ipi, pScore, triggered, spectral, gpz);
    }
    if (ipi >= 55) return _result(cell, tappedLatitude, tappedLongitude, distanceMeters, 'HOLD', 'HOLD', 'أولوية مراجعة، لا تصعيد قبل إثبات SWIR/Clay أو شاهد ميداني.', ipi, pScore, triggered, spectral, gpz);
    if (ipi >= 35) return _result(cell, tappedLatitude, tappedLongitude, distanceMeters, 'Low HOLD', 'HOLD منخفض', 'احفظه كسياق ولا تحفر.', ipi, pScore, triggered, spectral, gpz);
    return _result(cell, tappedLatitude, tappedLongitude, distanceMeters, 'Reject', 'رفض', 'النقاط المجمعة ضعيفة.', ipi, pScore, triggered, spectral, gpz);
  }

  AnalysisResult _result(TargetCell cell, double lat, double lon, double dist, String decision, String title, String explanation, double ipi, double pScore, List<String> gates, SpectralIndices spectral, GpzRecommendation gpz) {
    return AnalysisResult(
      cell: cell,
      tappedLatitude: lat,
      tappedLongitude: lon,
      distanceMeters: dist,
      outsidePack: false,
      decision: decision,
      title: title,
      explanation: explanation,
      ipi: ipi,
      pScore: pScore,
      triggeredGates: List.unmodifiable(gates),
      spectral: spectral,
      gpz: gpz,
    );
  }
}
