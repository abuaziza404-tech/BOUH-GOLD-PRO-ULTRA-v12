import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:share_plus/share_plus.dart';
import 'package:http/http.dart' as http;

import '../../data/repositories/analysis_repository.dart';
import '../../data/repositories/workspace_repository.dart';
import '../../domain/models/analysis_result.dart';
import '../../domain/models/assistant_message.dart';
import '../../domain/models/field_log.dart';
import '../../domain/models/map_layer.dart';
import '../../domain/models/prediction_candidate.dart';
import '../../domain/models/target_cell.dart';
import '../../engines/export_engine.dart';
import '../../engines/local_ai_assistant_engine.dart';
import '../../engines/predictive_engine.dart';

class AppController extends ChangeNotifier {
  final AnalysisRepository analysisRepository;
  final WorkspaceRepository workspaceRepository;
  late final PredictiveEngine predictiveEngine;
  late final LocalAiAssistantEngine assistantEngine;
  late final ExportEngine exportEngine;

  bool loading = true;
  String? error;
  AnalysisResult? lastResult;
  String sortMode = 'ipi';
  int tabIndex = 0;
  List<PredictionCandidate> predictions = [];
  String lastExportPath = '';
  bool onlineAiEnabled = false;
  String onlineAiEndpoint = '';
  String onlineAiApiKey = '';
  String onlineAiModel = 'field-assistant';
  String customTileUrl = '';
  double? gpsLat;
  double? gpsLon;

  AppController({required this.analysisRepository, required this.workspaceRepository}) {
    predictiveEngine = PredictiveEngine();
    assistantEngine = LocalAiAssistantEngine(predictiveEngine);
    exportEngine = ExportEngine(workspaceRepository.storage);
  }

  Future<void> bootstrap() async {
    try {
      await analysisRepository.load();
      await workspaceRepository.load();
      predictions = predictiveEngine.generateCandidates(analysisRepository.cells, limit: 12);
      if (workspaceRepository.messages.isEmpty) {
        await sendAssistantCommand('عرّف النظام');
      }
    } catch (e) {
      error = '$e';
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  List<TargetCell> get targets {
    final list = [...analysisRepository.cells];
    if (sortMode == 'pscore') {
      list.sort((a, b) => (b.scores['PScore'] ?? 0).compareTo(a.scores['PScore'] ?? 0));
    } else if (sortMode == 'nearest') {
      list.sort((a, b) => a.id.compareTo(b.id));
    } else if (sortMode == 'elite') {
      list.sort((a, b) => _eliteScore(b).compareTo(_eliteScore(a)));
    } else {
      list.sort((a, b) => (b.scores['IPI'] ?? 0).compareTo(a.scores['IPI'] ?? 0));
    }
    return list;
  }

  List<MapLayer> get layers => workspaceRepository.layers;
  List<AssistantMessage> get messages => workspaceRepository.messages;

  List<MapLayer> get allDrawableLayers {
    final builtins = <MapLayer>[];
    final aoi = analysisRepository.aoi;
    final lineaments = analysisRepository.lineaments;
    builtins.add(MapLayer(id: 'builtin_aoi', name: 'AOI Regions', type: 'geojson', source: 'asset', enabled: true, featureCount: ((aoi['features'] as List?) ?? const []).length, content: _stringify(aoi), createdAt: DateTime.now()));
    builtins.add(MapLayer(id: 'builtin_lineaments', name: 'Lineaments', type: 'geojson', source: 'asset', enabled: true, featureCount: ((lineaments['features'] as List?) ?? const []).length, content: _stringify(lineaments), createdAt: DateTime.now()));
    builtins.addAll(layers);
    return builtins.where((l) => l.enabled).toList(growable: false);
  }

  void setTab(int index) {
    tabIndex = index;
    notifyListeners();
  }

  void setSortMode(String mode) {
    sortMode = mode;
    notifyListeners();
  }

  AnalysisResult analyze(double lat, double lon) {
    final result = analysisRepository.analyzePoint(lat, lon);
    lastResult = result;
    notifyListeners();
    return result;
  }

  Future<void> createFieldLog(String observation) async {
    final r = lastResult;
    if (r == null) return;
    await workspaceRepository.addFieldLog(FieldLog(
      id: 'log_${DateTime.now().millisecondsSinceEpoch}',
      targetId: r.cell?.id ?? 'manual_point',
      title: r.cell?.name ?? 'نقطة يدوية',
      latitude: r.tappedLatitude,
      longitude: r.tappedLongitude,
      observation: observation,
      decision: r.decision,
      createdAt: DateTime.now(),
    ));
    await workspaceRepository.refreshFiles();
    notifyListeners();
  }

  Future<void> addLayer(String name, String type, String content) async {
    await workspaceRepository.addLayerFromText(name: name, type: type, content: content);
    notifyListeners();
  }

  Future<void> toggleLayer(String id) async {
    await workspaceRepository.toggleLayer(id);
    notifyListeners();
  }

  Future<void> createProject(String name, String region, String description) async {
    await workspaceRepository.createProject(name, region, description);
    notifyListeners();
  }

  Future<void> sendAssistantCommand(String prompt) async {
    final now = DateTime.now();
    await workspaceRepository.addMessage(AssistantMessage(id: 'msg_u_${now.microsecondsSinceEpoch}', fromUser: true, text: prompt, createdAt: now));
    var reply = await _onlineAiReply(prompt);
    if (reply.trim().isEmpty) reply = assistantEngine.answer(prompt: prompt, repository: analysisRepository, predictions: predictions, lastResult: lastResult);
    await workspaceRepository.addMessage(AssistantMessage(id: 'msg_ai_${DateTime.now().microsecondsSinceEpoch}', fromUser: false, text: reply, createdAt: DateTime.now()));
    notifyListeners();
  }

  void refreshPredictions() {
    predictions = predictiveEngine.generateCandidates(analysisRepository.cells, limit: 12);
    notifyListeners();
  }

  Future<void> exportCsv() async {
    lastExportPath = await exportEngine.exportTargetsCsv(targets);
    await workspaceRepository.refreshFiles();
    notifyListeners();
  }

  Future<void> exportKml() async {
    lastExportPath = await exportEngine.exportTargetsKml(targets);
    await workspaceRepository.refreshFiles();
    notifyListeners();
  }

  Future<void> exportPredictionsGeoJson() async {
    lastExportPath = await exportEngine.exportPredictionsGeoJson(predictions);
    await workspaceRepository.refreshFiles();
    notifyListeners();
  }

  Future<void> saveSystemSnapshot() async {
    final text = StringBuffer()
      ..writeln('# BOUH GOLD PRO ULTRA v12.3 System Snapshot')
      ..writeln('Targets: ${targets.length}')
      ..writeln('Layers: ${workspaceRepository.layers.length}')
      ..writeln('Predictions: ${predictions.length}')
      ..writeln('Last Decision: ${lastResult?.decision ?? 'none'}')
      ..writeln('Rule: Structure → Pattern → Alteration → Confirmation → Decision');
    await workspaceRepository.writeSystemNote('system_snapshot', text.toString());
    notifyListeners();
  }


  Future<void> importAnyFiles() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.any, allowMultiple: true);
    if (result == null) return;
    for (final file in result.files) {
      if (file.path == null) continue;
      await workspaceRepository.importExternalFile(file.path!, file.name);
    }
    await workspaceRepository.refreshFiles();
    notifyListeners();
  }

  Future<void> shareAppInfo() async {
    await Share.share('بوح التضاريس\nBOUH GOLD PRO ULTRA v12.3\nتطوير وتصميم: أحمد أبوعزيزه الرشيدي\nDeveloped by Ahmed Abuaziza Al-Rashidi');
  }

  Future<void> shareLastExport() async {
    if (lastExportPath.isEmpty) return;
    final f = File(lastExportPath);
    if (await f.exists()) await Share.shareXFiles([XFile(lastExportPath)], text: 'ملف من تطبيق بوح التضاريس');
  }

  Future<void> locateGps() async {
    final status = await Permission.location.request();
    if (!status.isGranted && !status.isLimited) return;
    if (!await Geolocator.isLocationServiceEnabled()) return;
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;
    final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    gpsLat = pos.latitude;
    gpsLon = pos.longitude;
    notifyListeners();
  }

  void updateOnlineAi({required bool enabled, required String endpoint, required String apiKey, required String model}) {
    onlineAiEnabled = enabled;
    onlineAiEndpoint = endpoint;
    onlineAiApiKey = apiKey;
    onlineAiModel = model;
    notifyListeners();
  }

  Future<String> _onlineAiReply(String prompt) async {
    if (!onlineAiEnabled || onlineAiEndpoint.trim().isEmpty) return '';
    try {
      final headers = {'Content-Type': 'application/json'};
      if (onlineAiApiKey.trim().isNotEmpty) headers['Authorization'] = 'Bearer ${onlineAiApiKey.trim()}';
      final body = {
        'model': onlineAiModel.trim().isEmpty ? 'field-assistant' : onlineAiModel.trim(),
        'messages': [
          {'role': 'system', 'content': 'أنت مساعد عربي داخل تطبيق بوح التضاريس. اشرح بلغة سهلة للعامل والمطور، ولا ترفع أي نقطة بلا بنية ونمط وطين/SWIR وشاهد ميداني.'},
          {'role': 'user', 'content': prompt},
        ],
        'temperature': 0.25,
      };
      final res = await http.post(Uri.parse(onlineAiEndpoint.trim()), headers: headers, body: jsonEncode(body)).timeout(const Duration(seconds: 35));
      if (res.statusCode < 200 || res.statusCode >= 300) return '';
      final decoded = jsonDecode(utf8.decode(res.bodyBytes));
      if (decoded is Map && decoded['choices'] is List && decoded['choices'].isNotEmpty) {
        final first = decoded['choices'][0];
        if (first is Map && first['message'] is Map && first['message']['content'] != null) return first['message']['content'].toString();
        if (first is Map && first['text'] != null) return first['text'].toString();
      }
      if (decoded is Map && decoded['reply'] != null) return decoded['reply'].toString();
      return decoded.toString();
    } catch (_) {
      return '';
    }
  }

  double _eliteScore(TargetCell t) {
    final gates = t.gates;
    int active = 0;
    for (final k in ['structure', 'pattern', 'swir_clay', 'quartz_carrier', 'field_evidence']) {
      final v = '${gates[k] ?? ''}'.toLowerCase();
      if (v == 'yes' || v == 'partial') active++;
    }
    return ((t.scores['IPI'] ?? 0) * 2) + ((t.scores['PScore'] ?? 0) * 0.7) + active * 20;
  }

  String _stringify(Map<String, dynamic> map) => map.isEmpty ? '{}' : jsonEncode(map);
}
