
import 'package:flutter/material.dart';
import 'home_shell.dart';

class AuthGateScreen extends StatefulWidget {
  const AuthGateScreen({super.key});

  @override
  State<AuthGateScreen> createState() => _AuthGateScreenState();
}

class _AuthGateScreenState extends State<AuthGateScreen> {
  static const _password = 'Abuaziza2000';
  final controller = TextEditingController();
  bool hide = true;
  String error = '';

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(children: [
        Positioned.fill(child: Image.asset('assets/branding/bouh_interface.png', fit: BoxFit.cover, opacity: const AlwaysStoppedAnimation(0.42))),
        Positioned.fill(child: Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xFF050806), Color(0xFF050806)])))),
        SafeArea(
          child: ListView(padding: const EdgeInsets.all(24), children: [
            const SizedBox(height: 58),
            const Text('بوح التضاريس', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFFFFD700), fontSize: 42, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('BOUH GOLD PRO ULTRA v12.3', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('تطوير وتصميم: أحمد أبوعزيزه الرشيدي', textAlign: TextAlign.center, style: TextStyle(color: Colors.white70, fontSize: 13)),
            const Text('Developed by Ahmed Abuaziza Al-Rashidi', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, fontSize: 12)),
            const SizedBox(height: 34),
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: const Color(0xEE101611), borderRadius: BorderRadius.circular(26), border: Border.all(color: const Color(0x99FFD700))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                const Text('بوابة الدخول', style: TextStyle(color: Color(0xFFFFD700), fontSize: 22, fontWeight: FontWeight.w900)),
                const SizedBox(height: 10),
                const Text('أدخل كلمة المرور لفتح الخرائط والطبقات والملفات والمساعد.', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 16),
                TextField(
                  controller: controller,
                  obscureText: hide,
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(labelText: 'كلمة المرور', errorText: error.isEmpty ? null : error, suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility : Icons.visibility_off), onPressed: () => setState(() => hide = !hide))),
                  onSubmitted: (_) => _login(),
                ),
                const SizedBox(height: 14),
                FilledButton.icon(onPressed: _login, icon: const Icon(Icons.lock_open), label: const Text('دخول')),
              ]),
            ),
            const SizedBox(height: 18),
            const Text('ملاحظة: التطبيق لا يثبت وجود ذهب اقتصادي وحده. النتائج تحتاج فحص ميداني + عينة + تحليل + QA/QC.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white54, height: 1.45)),
          ]),
        ),
      ]),
    );
  }

  void _login() {
    if (controller.text.trim() == _password) {
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const Directionality(textDirection: TextDirection.rtl, child: HomeShell())));
    } else {
      setState(() => error = 'كلمة المرور غير صحيحة');
    }
  }
}
