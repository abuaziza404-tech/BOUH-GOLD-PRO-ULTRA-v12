import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/app_controller.dart';

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final input = TextEditingController();

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<AppController>(builder: (context, controller, _) {
      return Scaffold(
        appBar: AppBar(title: const Text('المساعد المحلي BOUH AI'), actions: [IconButton(onPressed: () => _quick(context, controller), icon: const Icon(Icons.flash_on))]),
        body: Column(children: [
          Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: const Color(0xFF101611), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0x33FFD700))),
            child: const Text('مساعد بوح يعمل بطريقتين: داخلي بدون إنترنت لقواعد بوح، أو عبر الإنترنت إذا أضفت رابط ومفتاح مزود AI من إعدادات النظام. يشرح المصطلحات بلغة سهلة للعامل والمطور.', style: TextStyle(color: Colors.white70)),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: controller.messages.length,
              itemBuilder: (_, i) {
                final m = controller.messages[i];
                return Align(
                  alignment: m.fromUser ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    constraints: const BoxConstraints(maxWidth: 320),
                    margin: const EdgeInsets.symmetric(vertical: 5),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: m.fromUser ? const Color(0xFF24331A) : const Color(0xFF0B160E), borderRadius: BorderRadius.circular(18), border: Border.all(color: m.fromUser ? const Color(0x665CD85C) : const Color(0x55FFD700))),
                    child: Text(m.text, style: const TextStyle(color: Colors.white, height: 1.35)),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 4, 10, 10),
              child: Row(children: [
                Expanded(child: TextField(controller: input, minLines: 1, maxLines: 4, decoration: const InputDecoration(hintText: 'اسأل: أفضل هدف، تحليل 19.6045911 36.9171953، GPZ...', border: OutlineInputBorder()))),
                const SizedBox(width: 8),
                IconButton.filled(onPressed: () async { final text = input.text; input.clear(); await controller.sendAssistantCommand(text); }, icon: const Icon(Icons.send)),
              ]),
            ),
          ),
        ]),
      );
    });
  }

  Future<void> _quick(BuildContext context, AppController controller) async {
    await showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Wrap(children: [
      _cmd(controller, 'أفضل هدف'),
      _cmd(controller, 'GPZ للنقطة الأخيرة'),
      _cmd(controller, 'اشرح بوابات القتل'),
      _cmd(controller, 'كيف أضيف طبقة؟'),
      _cmd(controller, 'تصدير KML'),
    ])));
  }

  Widget _cmd(AppController c, String text) => ListTile(title: Text(text), onTap: () async { Navigator.pop(context); await c.sendAssistantCommand(text); });
}
