import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/app_controller.dart';
import '../widgets/analysis_bottom_sheet.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppController>(builder: (context, controller, _) {
      return Scaffold(
        appBar: AppBar(title: const Text('محرك التنبؤ والاستهداف'), actions: [IconButton(onPressed: controller.refreshPredictions, icon: const Icon(Icons.refresh))]),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _summary(controller),
            const SizedBox(height: 14),
            const Text('أقوى نقاط المتابعة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFFFFD700))),
            const SizedBox(height: 10),
            for (final p in controller.predictions) _predictionCard(context, controller, p),
          ],
        ),
      );
    });
  }

  Widget _summary(AppController c) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: const Color(0xFF101611), borderRadius: BorderRadius.circular(24), border: Border.all(color: const Color(0x33FFD700))),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('BOUH Predictive Engine', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.w900, fontSize: 18)),
          const SizedBox(height: 8),
          const Text('التنبؤ هنا محلي ومحافظ: لا يرفع أي نقطة بلا Structure + Pattern + SWIR/Clay أو شاهد ميداني. ليس إثباتًا اقتصاديًا قبل assay وQA/QC.', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          Row(children: [
            _stat('Cells', '${c.targets.length}'),
            _stat('Pred', '${c.predictions.length}'),
            _stat('Layers', '${c.allDrawableLayers.length}'),
          ]),
        ]),
      );

  Widget _stat(String label, String value) => Expanded(child: Container(margin: const EdgeInsets.symmetric(horizontal: 4), padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(18)), child: Column(children: [Text(value, style: const TextStyle(color: Color(0xFFFFD700), fontSize: 22, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: Colors.white54))])));

  Widget _predictionCard(BuildContext context, AppController controller, dynamic p) {
    final color = p.decision.contains('Target') ? const Color(0xFFFFD700) : p.decision.contains('Candidate') ? const Color(0xFF3DDC84) : const Color(0xFFFFB020);
    return Card(
      color: const Color(0xFF0C120D),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: color.withOpacity(0.35))),
      child: ListTile(
        title: Text('${p.name} — ${p.decision}', style: TextStyle(color: color, fontWeight: FontWeight.w900)),
        subtitle: Text('IPI ${p.ipi.toStringAsFixed(1)} | P ${p.pScore.toStringAsFixed(1)}\n${p.reason}\n${p.nextAction}', style: const TextStyle(color: Colors.white70)),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_left),
        onTap: () {
          final r = controller.analyze(p.latitude, p.longitude);
          showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => FractionallySizedBox(heightFactor: 0.90, child: AnalysisBottomSheet(result: r)));
        },
      ),
    );
  }
}
