import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/app_controller.dart';

class SystemScreen extends StatelessWidget {
  const SystemScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppController>(builder: (context, controller, _) {
      return Scaffold(
        appBar: AppBar(title: const Text('النظام والتطوير الداخلي')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _card('هوية النظام', 'BOUH GOLD PRO ULTRA v12.3\nتطوير وتصميم: أحمد أبوعزيزه الرشيدي\nDark Field Mode — Offline Enterprise Workspace', Icons.shield),
            _card('حزمة Red Sea Hills', 'أهداف على الخريطة: 0\nPredictions: ${controller.predictions.length}\nDrawable Layers: ${controller.allDrawableLayers.length}\nWorkspace Files: ${controller.workspaceRepository.files.length}', Icons.storage),
            _card('قانون القرار', 'Structure → Pattern → Alteration → Confirmation → Decision\nNo Structure = Reject\nNo Pattern = Reject/HOLD\nNo Clay/SWIR = HOLD\nFeOx alone = Reject\nNo economic claim without Field Validation + Assay + QA/QC', Icons.rule),

            const SizedBox(height: 14),
            const Text('إعدادات AI والخرائط', style: TextStyle(color: Color(0xFFFFD700), fontSize: 20, fontWeight: FontWeight.w900)),
            _aiSettings(context, controller),
            _card('مصادر الخرائط الحقيقية', 'المتاح الآن: Offline Canvas + طبقات المستخدم. لإضافة Google Satellite أو ASTER/Landsat أو مغناطيسية/جاذبية/رادار استخدم روابط XYZ/WMS/WMTS قانونية من مزودك أو خادم GIS. لا يتم تضمين Google tiles مباشرة بدون ترخيص.', Icons.satellite_alt),
            const SizedBox(height: 14),
            const Text('المشاريع الداخلية', style: TextStyle(color: Color(0xFFFFD700), fontSize: 20, fontWeight: FontWeight.w900)),
            for (final p in controller.workspaceRepository.projects)
              Card(color: const Color(0xFF0C120D), child: ListTile(leading: const Icon(Icons.account_tree, color: Color(0xFFFFD700)), title: Text(p.name), subtitle: Text('${p.region}\n${p.description}', style: const TextStyle(color: Colors.white60)), isThreeLine: true)),
            const SizedBox(height: 8),
            FilledButton.icon(onPressed: () => _newProject(context, controller), icon: const Icon(Icons.add), label: const Text('إنشاء مشروع داخلي')),
            OutlinedButton.icon(onPressed: controller.saveSystemSnapshot, icon: const Icon(Icons.save), label: const Text('حفظ لقطة النظام')),
          ],
        ),
      );
    });
  }


  Widget _aiSettings(BuildContext context, AppController controller) {
    final endpoint = TextEditingController(text: controller.onlineAiEndpoint);
    final key = TextEditingController(text: controller.onlineAiApiKey);
    final model = TextEditingController(text: controller.onlineAiModel);
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: const Color(0xFF101611), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0x33FFD700))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        SwitchListTile(
          value: controller.onlineAiEnabled,
          onChanged: (v) => controller.updateOnlineAi(enabled: v, endpoint: endpoint.text, apiKey: key.text, model: model.text),
          title: const Text('تشغيل AI عبر الإنترنت'),
          subtitle: const Text('إذا لم تضع رابط ومفتاح، يعمل المساعد الداخلي بدون إنترنت.', style: TextStyle(color: Colors.white60)),
        ),
        TextField(controller: endpoint, decoration: const InputDecoration(labelText: 'رابط مزود AI')),
        TextField(controller: key, obscureText: true, decoration: const InputDecoration(labelText: 'مفتاح AI')),
        TextField(controller: model, decoration: const InputDecoration(labelText: 'اسم النموذج')),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: () => controller.updateOnlineAi(enabled: controller.onlineAiEnabled, endpoint: endpoint.text, apiKey: key.text, model: model.text), icon: const Icon(Icons.save), label: const Text('حفظ إعدادات AI')),
      ]),
    );
  }

  Widget _card(String title, String body, IconData icon) => Container(margin: const EdgeInsets.only(bottom: 12), padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFF101611), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0x33FFD700))), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFFFFD700)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.w900, fontSize: 18)), const SizedBox(height: 6), Text(body, style: const TextStyle(color: Colors.white70, height: 1.4))]))]));

  Future<void> _newProject(BuildContext context, AppController controller) async {
    final name = TextEditingController(text: 'مشروع ميداني جديد');
    final region = TextEditingController(text: 'Red Sea Hills');
    final desc = TextEditingController(text: 'مشروع داخلي لإضافة طبقات ونقاط وملفات حقلية.');
    await showDialog(context: context, builder: (_) => AlertDialog(title: const Text('إنشاء مشروع'), content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم المشروع')), TextField(controller: region, decoration: const InputDecoration(labelText: 'النطاق')), TextField(controller: desc, decoration: const InputDecoration(labelText: 'الوصف'))]), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')), FilledButton(onPressed: () async { await controller.createProject(name.text, region.text, desc.text); if (context.mounted) Navigator.pop(context); }, child: const Text('حفظ'))]));
  }
}
