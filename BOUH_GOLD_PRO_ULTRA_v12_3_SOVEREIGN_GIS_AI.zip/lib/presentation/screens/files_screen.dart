import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../controllers/app_controller.dart';

class FilesScreen extends StatelessWidget {
  const FilesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<AppController>(builder: (context, controller, _) {
      final bytes = controller.workspaceRepository.bytesUsed;
      return Scaffold(
        appBar: AppBar(title: const Text('الملفات والصادرات الداخلية')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: const Color(0xFF101611), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0x33FFD700))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('مساحة العمل الداخلية', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.w900, fontSize: 18)),
                const SizedBox(height: 8),
                Text(controller.workspaceRepository.rootPath, style: const TextStyle(color: Colors.white54, fontSize: 12)),
                const SizedBox(height: 8),
                Text('الحجم المستخدم: ${(bytes / (1024 * 1024)).toStringAsFixed(2)} MB', style: const TextStyle(color: Colors.white70)),
              ]),
            ),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: [
              FilledButton.icon(onPressed: controller.importAnyFiles, icon: const Icon(Icons.upload_file), label: const Text('رفع ملفات')),
              OutlinedButton.icon(onPressed: controller.shareLastExport, icon: const Icon(Icons.share), label: const Text('مشاركة آخر ملف')),
              FilledButton.icon(onPressed: controller.exportKml, icon: const Icon(Icons.public), label: const Text('تصدير KML')),
              FilledButton.icon(onPressed: controller.exportCsv, icon: const Icon(Icons.table_chart), label: const Text('تصدير CSV')),
              FilledButton.icon(onPressed: controller.exportPredictionsGeoJson, icon: const Icon(Icons.data_object), label: const Text('تصدير GeoJSON')),
              OutlinedButton.icon(onPressed: controller.saveSystemSnapshot, icon: const Icon(Icons.save), label: const Text('Snapshot')),
            ]),
            if (controller.lastExportPath.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text('آخر ملف: ${controller.lastExportPath}', style: const TextStyle(color: Color(0xFFFFD700)))),
            const SizedBox(height: 18),
            const Text('قائمة الملفات', style: TextStyle(color: Color(0xFFFFD700), fontSize: 20, fontWeight: FontWeight.w900)),
            for (final f in controller.workspaceRepository.files)
              Card(
                color: const Color(0xFF0C120D),
                child: ListTile(
                  leading: const Icon(Icons.insert_drive_file, color: Color(0xFFFFD700)),
                  title: Text(f.name, overflow: TextOverflow.ellipsis),
                  subtitle: Text('${f.kind} | ${(f.bytes / 1024).toStringAsFixed(1)} KB\n${f.path}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54)),
                ),
              ),
          ],
        ),
      );
    });
  }
}
