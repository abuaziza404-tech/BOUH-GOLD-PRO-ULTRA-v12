import 'dart:math' as math;

class GeoMath {
  static const double earthRadiusMeters = 6371008.8;

  static double _radians(double degrees) => degrees * math.pi / 180.0;

  static double haversineMeters({
    required double lat1,
    required double lon1,
    required double lat2,
    required double lon2,
  }) {
    final phi1 = _radians(lat1);
    final phi2 = _radians(lat2);
    final dPhi = _radians(lat2 - lat1);
    final dLambda = _radians(lon2 - lon1);
    final a = math.sin(dPhi / 2) * math.sin(dPhi / 2) +
        math.cos(phi1) * math.cos(phi2) * math.sin(dLambda / 2) * math.sin(dLambda / 2);
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    return earthRadiusMeters * c;
  }

  static double clampDouble(double value, double min, double max) {
    if (value < min) return min;
    if (value > max) return max;
    return value;
  }
}
