import '../../core/utils/geo_math.dart';
import '../../domain/models/analysis_result.dart';
import '../../domain/models/gpz_recommendation.dart';
import '../../domain/models/target_cell.dart';
import '../../engines/bouh_supreme_engine.dart';
import '../../engines/gpz_engine.dart';
import '../../engines/spectral_engine.dart';
import '../datasources/local_pack_datasource.dart';

class NearestCell {
  final TargetCell? cell;
  final double distanceMeters;
  const NearestCell(this.cell, this.distanceMeters);
}

class AnalysisRepository {
  final LocalPackDataSource dataSource;
  final SpectralEngine _spectralEngine = SpectralEngine();
  final GpzEngine _gpzEngine = GpzEngine();
  final BouhSupremeEngine _bouhEngine = BouhSupremeEngine();

  Map<String, dynamic>? _manifest;
  Map<String, dynamic>? _killMatrix;
  Map<String, dynamic>? _aoi;
  Map<String, dynamic>? _lineaments;
  List<TargetCell>? _cells;

  AnalysisRepository(this.dataSource);

  Future<void> load() async {
    _manifest ??= await dataSource.loadManifest();
    _killMatrix ??= await dataSource.loadKillMatrix();
    _aoi ??= await dataSource.loadAoiRegions();
    _lineaments ??= await dataSource.loadLineaments();
    if (_cells == null) {
      final grid = await dataSource.loadGridIndex();
      final list = (grid['cells'] as List<dynamic>).cast<Map<String, dynamic>>();
      _cells = list.map(TargetCell.fromJson).toList(growable: false);
    }
  }

  Map<String, dynamic> get manifest => _manifest ?? const {};
  Map<String, dynamic> get killMatrix => _killMatrix ?? const {};
  Map<String, dynamic> get aoi => _aoi ?? const {'features': []};
  Map<String, dynamic> get lineaments => _lineaments ?? const {'features': []};
  List<TargetCell> get cells => _cells ?? const [];

  NearestCell findNearest(double lat, double lon) {
    TargetCell? best;
    var bestDistance = double.infinity;
    for (final cell in cells) {
      final distance = GeoMath.haversineMeters(lat1: lat, lon1: lon, lat2: cell.latitude, lon2: cell.longitude);
      if (distance < bestDistance) {
        bestDistance = distance;
        best = cell;
      }
    }
    return NearestCell(best, bestDistance);
  }

  AnalysisResult analyzePoint(double lat, double lon) {
    final nearest = findNearest(lat, lon);
    final spectral = nearest.cell == null ? _spectralEngine.compute(const {'has_raw_bands': false}) : _spectralEngine.compute(nearest.cell!.spectral);
    final GpzRecommendation gpz = _gpzEngine.recommend(magneticRisk: nearest.cell?.magneticRisk ?? 0.6, spectral: spectral);
    return _bouhEngine.analyze(
      cell: nearest.cell,
      tappedLatitude: lat,
      tappedLongitude: lon,
      distanceMeters: nearest.distanceMeters,
      spectral: spectral,
      gpz: gpz,
    );
  }
}
