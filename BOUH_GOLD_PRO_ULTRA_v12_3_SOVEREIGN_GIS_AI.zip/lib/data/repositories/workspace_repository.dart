import 'dart:convert';
import 'dart:io';

import '../../domain/models/app_project.dart';
import '../../domain/models/assistant_message.dart';
import '../../domain/models/field_log.dart';
import '../../domain/models/internal_file_record.dart';
import '../../domain/models/map_layer.dart';
import '../services/app_storage_service.dart';

class WorkspaceRepository {
  final AppStorageService storage = AppStorageService();

  List<AppProject> projects = [];
  List<MapLayer> layers = [];
  List<InternalFileRecord> files = [];
  List<AssistantMessage> messages = [];
  List<FieldLog> fieldLogs = [];
  String rootPath = '';
  int bytesUsed = 0;

  Future<void> load() async {
    rootPath = await storage.rootPath();
    projects = (await storage.readList('projects/projects.json')).map(AppProject.fromJson).toList();
    if (projects.isEmpty) {
      projects = [AppProject.seed()];
      await saveProjects();
    }
    layers = (await storage.readList('layers/user_layers.json')).map(MapLayer.fromJson).toList();
    messages = (await storage.readList('ai_memory/messages.json')).map(AssistantMessage.fromJson).toList();
    fieldLogs = (await storage.readList('logs/field_logs.json')).map(FieldLog.fromJson).toList();
    await refreshFiles();
    bytesUsed = await storage.workspaceBytes();
  }

  Future<void> saveProjects() => storage.writeList('projects/projects.json', projects.map((e) => e.toJson()).toList());
  Future<void> saveLayers() => storage.writeList('layers/user_layers.json', layers.map((e) => e.toJson()).toList());
  Future<void> saveMessages() => storage.writeList('ai_memory/messages.json', messages.map((e) => e.toJson()).toList());
  Future<void> saveFieldLogs() => storage.writeList('logs/field_logs.json', fieldLogs.map((e) => e.toJson()).toList());

  Future<void> createProject(String name, String region, String description) async {
    final now = DateTime.now();
    projects.insert(0, AppProject(id: 'project_${now.millisecondsSinceEpoch}', name: name, region: region, description: description, createdAt: now, updatedAt: now, targetCount: 0, layerCount: layers.length, status: 'Active'));
    await saveProjects();
  }

  Future<MapLayer> addLayerFromText({required String name, required String type, required String content}) async {
    final now = DateTime.now();
    final layer = MapLayer(
      id: 'layer_${now.millisecondsSinceEpoch}',
      name: name,
      type: type,
      source: 'manual_internal',
      enabled: true,
      featureCount: _countFeatures(content),
      content: content,
      createdAt: now,
    );
    layers.insert(0, layer);
    await saveLayers();
    await storage.writeText('layers/${layer.id}_${_safe(name)}.$type', content);
    await refreshFiles();
    return layer;
  }

  Future<void> toggleLayer(String id) async {
    layers = layers.map((l) => l.id == id ? l.copyWith(enabled: !l.enabled) : l).toList();
    await saveLayers();
  }

  Future<void> addMessage(AssistantMessage message) async {
    messages.add(message);
    await saveMessages();
  }

  Future<void> addFieldLog(FieldLog log) async {
    fieldLogs.insert(0, log);
    await saveFieldLogs();
  }

  Future<void> writeSystemNote(String title, String content) async {
    final name = 'systems/${DateTime.now().millisecondsSinceEpoch}_${_safe(title)}.md';
    await storage.writeText(name, content);
    await refreshFiles();
  }


  Future<void> importExternalFile(String sourcePath, String originalName) async {
    final src = File(sourcePath);
    if (!await src.exists()) return;
    final safe = _safe(originalName.isEmpty ? src.uri.pathSegments.last : originalName);
    final relative = 'files/${DateTime.now().millisecondsSinceEpoch}_$safe';
    final dest = await storage.file(relative);
    await src.copy(dest.path);
    final lower = originalName.toLowerCase();
    if (lower.endsWith('.geojson') || lower.endsWith('.json') || lower.endsWith('.kml')) {
      final content = await dest.readAsString(errors: false);
      await addLayerFromText(name: originalName, type: lower.endsWith('.kml') ? 'kml' : 'geojson', content: content);
    }
    await refreshFiles();
  }

  Future<void> refreshFiles() async {
    final records = <InternalFileRecord>[];
    final root = Directory(await storage.rootPath());
    if (await root.exists()) {
      await for (final entity in root.list(recursive: true, followLinks: false)) {
        if (entity is File) {
          final stat = await entity.stat();
          records.add(InternalFileRecord(id: entity.path.hashCode.toString(), name: entity.uri.pathSegments.last, path: entity.path, kind: entity.path.split('.').last.toLowerCase(), bytes: stat.size, createdAt: stat.modified));
        }
      }
    }
    records.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    files = records;
    bytesUsed = await storage.workspaceBytes();
  }

  int _countFeatures(String content) {
    try {
      final decoded = jsonDecode(content);
      if (decoded is Map && decoded['features'] is List) return (decoded['features'] as List).length;
      if (decoded is Map && decoded['type'] != null) return 1;
    } catch (_) {
      final placemarks = RegExp('<Placemark', caseSensitive: false).allMatches(content).length;
      if (placemarks > 0) return placemarks;
    }
    return content.trim().isEmpty ? 0 : 1;
  }

  String _safe(String s) => s.replaceAll(RegExp(r'[^A-Za-z0-9_\-]+'), '_');
}
