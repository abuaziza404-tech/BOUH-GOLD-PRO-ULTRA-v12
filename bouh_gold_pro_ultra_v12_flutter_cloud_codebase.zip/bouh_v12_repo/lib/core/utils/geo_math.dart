import 'dart:async';
import 'dart:isolate';
import 'dart:math' as math;

class GeoPoint {
  const GeoPoint({required this.latitude, required this.longitude});

  final double latitude;
  final double longitude;

  Map<String, double> toJson() => <String, double>{
        'lat': latitude,
        'lon': longitude,
      };
}

class NearestCellResult {
  const NearestCellResult({
    required this.index,
    required this.cell,
    required this.distanceMeters,
    required this.latitude,
    required this.longitude,
  });

  final int index;
  final Map<String, dynamic> cell;
  final double distanceMeters;
  final double latitude;
  final double longitude;

  bool get found => index >= 0;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'index': index,
        'cell': cell,
        'distance_m': distanceMeters,
        'lat': latitude,
        'lon': longitude,
      };
}

class GeoMath {
  GeoMath._();

  static const double earthRadiusMeters = 6371008.8;

  static double degreesToRadians(double degrees) => degrees * math.pi / 180.0;

  static double radiansToDegrees(double radians) => radians * 180.0 / math.pi;

  static double normalizeLongitude(double longitude) {
    var lon = longitude;
    while (lon > 180.0) {
      lon -= 360.0;
    }
    while (lon < -180.0) {
      lon += 360.0;
    }
    return lon;
  }

  static double clampLatitude(double latitude) => latitude.clamp(-90.0, 90.0).toDouble();

  static double haversineDistanceMeters({
    required double lat1,
    required double lon1,
    required double lat2,
    required double lon2,
  }) {
    final phi1 = degreesToRadians(clampLatitude(lat1));
    final phi2 = degreesToRadians(clampLatitude(lat2));
    final deltaPhi = degreesToRadians(clampLatitude(lat2) - clampLatitude(lat1));
    final deltaLambda = degreesToRadians(normalizeLongitude(lon2) - normalizeLongitude(lon1));

    final sinDeltaPhi = math.sin(deltaPhi / 2.0);
    final sinDeltaLambda = math.sin(deltaLambda / 2.0);
    final a = (sinDeltaPhi * sinDeltaPhi) +
        math.cos(phi1) * math.cos(phi2) * sinDeltaLambda * sinDeltaLambda;
    final c = 2.0 * math.atan2(math.sqrt(a), math.sqrt(1.0 - a));
    return earthRadiusMeters * c;
  }

  static double initialBearingDegrees({
    required double lat1,
    required double lon1,
    required double lat2,
    required double lon2,
  }) {
    final phi1 = degreesToRadians(lat1);
    final phi2 = degreesToRadians(lat2);
    final lambda1 = degreesToRadians(lon1);
    final lambda2 = degreesToRadians(lon2);
    final y = math.sin(lambda2 - lambda1) * math.cos(phi2);
    final x = math.cos(phi1) * math.sin(phi2) -
        math.sin(phi1) * math.cos(phi2) * math.cos(lambda2 - lambda1);
    final bearing = radiansToDegrees(math.atan2(y, x));
    return (bearing + 360.0) % 360.0;
  }

  static double _readDouble(Map<String, dynamic> cell, List<String> keys) {
    for (final key in keys) {
      final value = cell[key];
      if (value is num) return value.toDouble();
      if (value is String) {
        final parsed = double.tryParse(value.trim());
        if (parsed != null) return parsed;
      }
    }
    return double.nan;
  }

  static List<Map<String, dynamic>> normalizeDynamicCellList(List<dynamic> cells) {
    final normalized = <Map<String, dynamic>>[];
    for (final item in cells) {
      if (item is Map<String, dynamic>) {
        normalized.add(item);
      } else if (item is Map) {
        normalized.add(item.map((key, value) => MapEntry(key.toString(), value)));
      }
    }
    return normalized;
  }

  static NearestCellResult? findNearestCellSync({
    required double latitude,
    required double longitude,
    required List<dynamic> cells,
    List<String> latitudeKeys = const <String>['lat', 'latitude', 'center_lat', 'y'],
    List<String> longitudeKeys = const <String>['lon', 'lng', 'longitude', 'center_lon', 'x'],
    double maxDistanceMeters = double.infinity,
    int shortlistSize = 16,
  }) {
    if (cells.isEmpty) return null;

    final normalized = normalizeDynamicCellList(cells);
    if (normalized.isEmpty) return null;

    final latRad = degreesToRadians(latitude);
    final metersPerLatDegree = 111132.92 -
        559.82 * math.cos(2.0 * latRad) +
        1.175 * math.cos(4.0 * latRad) -
        0.0023 * math.cos(6.0 * latRad);
    final metersPerLonDegree = 111412.84 * math.cos(latRad) -
        93.5 * math.cos(3.0 * latRad) +
        0.118 * math.cos(5.0 * latRad);

    final shortlist = <_CandidateDistance>[];
    for (var i = 0; i < normalized.length; i++) {
      final cell = normalized[i];
      final cLat = _readDouble(cell, latitudeKeys);
      final cLon = _readDouble(cell, longitudeKeys);
      if (!cLat.isFinite || !cLon.isFinite) continue;
      final dy = (cLat - latitude) * metersPerLatDegree;
      final dx = (normalizeLongitude(cLon) - normalizeLongitude(longitude)) * metersPerLonDegree;
      final approxSquared = (dx * dx) + (dy * dy);
      shortlist.add(_CandidateDistance(i, approxSquared, cLat, cLon, cell));
    }

    if (shortlist.isEmpty) return null;
    shortlist.sort((a, b) => a.approxSquared.compareTo(b.approxSquared));

    final limit = math.min(math.max(1, shortlistSize), shortlist.length);
    var bestIndex = -1;
    var bestDistance = double.infinity;
    var bestLat = double.nan;
    var bestLon = double.nan;
    Map<String, dynamic>? bestCell;

    for (var i = 0; i < limit; i++) {
      final candidate = shortlist[i];
      final exactDistance = haversineDistanceMeters(
        lat1: latitude,
        lon1: longitude,
        lat2: candidate.latitude,
        lon2: candidate.longitude,
      );
      if (exactDistance < bestDistance) {
        bestDistance = exactDistance;
        bestIndex = candidate.originalIndex;
        bestLat = candidate.latitude;
        bestLon = candidate.longitude;
        bestCell = candidate.cell;
      }
    }

    if (bestIndex < 0 || bestCell == null || bestDistance > maxDistanceMeters) return null;
    return NearestCellResult(
      index: bestIndex,
      cell: bestCell,
      distanceMeters: bestDistance,
      latitude: bestLat,
      longitude: bestLon,
    );
  }

  static Future<NearestCellResult?> findNearestCellAsync({
    required double latitude,
    required double longitude,
    required List<dynamic> cells,
    List<String> latitudeKeys = const <String>['lat', 'latitude', 'center_lat', 'y'],
    List<String> longitudeKeys = const <String>['lon', 'lng', 'longitude', 'center_lon', 'x'],
    double maxDistanceMeters = double.infinity,
    int shortlistSize = 16,
    int isolateThreshold = 700,
  }) async {
    if (cells.length < isolateThreshold) {
      return findNearestCellSync(
        latitude: latitude,
        longitude: longitude,
        cells: cells,
        latitudeKeys: latitudeKeys,
        longitudeKeys: longitudeKeys,
        maxDistanceMeters: maxDistanceMeters,
        shortlistSize: shortlistSize,
      );
    }

    final payload = <String, dynamic>{
      'latitude': latitude,
      'longitude': longitude,
      'cells': normalizeDynamicCellList(cells),
      'latitude_keys': latitudeKeys,
      'longitude_keys': longitudeKeys,
      'max_distance_m': maxDistanceMeters,
      'shortlist_size': shortlistSize,
    };

    final resultJson = await Isolate.run<Map<String, dynamic>?>(() => _nearestCellIsolate(payload));
    if (resultJson == null) return null;
    final cell = resultJson['cell'];
    if (cell is! Map) return null;
    return NearestCellResult(
      index: (resultJson['index'] as num).toInt(),
      cell: cell.map((key, value) => MapEntry(key.toString(), value)),
      distanceMeters: (resultJson['distance_m'] as num).toDouble(),
      latitude: (resultJson['lat'] as num).toDouble(),
      longitude: (resultJson['lon'] as num).toDouble(),
    );
  }
}

class _CandidateDistance {
  const _CandidateDistance(
    this.originalIndex,
    this.approxSquared,
    this.latitude,
    this.longitude,
    this.cell,
  );

  final int originalIndex;
  final double approxSquared;
  final double latitude;
  final double longitude;
  final Map<String, dynamic> cell;
}

Map<String, dynamic>? _nearestCellIsolate(Map<String, dynamic> payload) {
  final cells = payload['cells'];
  if (cells is! List) return null;
  final latitudeKeys = (payload['latitude_keys'] as List).map((e) => e.toString()).toList();
  final longitudeKeys = (payload['longitude_keys'] as List).map((e) => e.toString()).toList();
  final result = GeoMath.findNearestCellSync(
    latitude: (payload['latitude'] as num).toDouble(),
    longitude: (payload['longitude'] as num).toDouble(),
    cells: cells,
    latitudeKeys: latitudeKeys,
    longitudeKeys: longitudeKeys,
    maxDistanceMeters: (payload['max_distance_m'] as num).toDouble(),
    shortlistSize: (payload['shortlist_size'] as num).toInt(),
  );
  return result?.toJson();
}
