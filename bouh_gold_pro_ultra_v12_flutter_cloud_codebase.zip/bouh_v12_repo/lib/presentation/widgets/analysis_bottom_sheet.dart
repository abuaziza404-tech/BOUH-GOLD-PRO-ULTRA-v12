import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../data/repositories/analysis_repository.dart';
import '../../engines/bouh_supreme_engine.dart';

class AnalysisBottomSheet extends StatelessWidget {
  const AnalysisBottomSheet({super.key, required this.analysis});

  final CoordinateAnalysisResult analysis;

  @override
  Widget build(BuildContext context) {
    final palette = _SheetPalette.fromStatus(analysis.engineResult.decisionStatus);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        decoration: BoxDecoration(
          color: palette.background,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          border: Border(top: BorderSide(color: palette.accent, width: 2.2)),
          boxShadow: <BoxShadow>[
            BoxShadow(color: palette.accent.withOpacity(0.25), blurRadius: 24, spreadRadius: 2),
          ],
        ),
        child: Stack(
          children: <Widget>[
            if (analysis.engineResult.isElite) const Positioned.fill(child: _GoldParticleField()),
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(18, 12, 18, 20),
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: <Widget>[
                      Center(
                        child: Container(
                          width: 54,
                          height: 5,
                          decoration: BoxDecoration(
                            color: palette.accent.withOpacity(0.7),
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      _Header(analysis: analysis, palette: palette),
                      const SizedBox(height: 14),
                      _ScoreStrip(analysis: analysis, palette: palette),
                      const SizedBox(height: 16),
                      _SectionTitle(title: 'المؤشرات الطيفية المحسوبة', color: palette.accent),
                      const SizedBox(height: 8),
                      _MetricGrid(metrics: <_MetricItem>[
                        _MetricItem('Iron Index B4/B2', analysis.spectralMetrics.ironIndex),
                        _MetricItem('Quartz Index B11/B12', analysis.spectralMetrics.quartzIndex),
                        _MetricItem('Alteration (B11+B12)/B8', analysis.spectralMetrics.alterationIndex),
                        _MetricItem('NDMI', analysis.spectralMetrics.ndmi),
                      ]),
                      const SizedBox(height: 16),
                      _SectionTitle(title: 'مصفوفة القتل والبوابات الصارمة', color: palette.accent),
                      const SizedBox(height: 8),
                      _GatesPanel(analysis: analysis, palette: palette),
                      const SizedBox(height: 16),
                      _SectionTitle(title: 'بصمة التشابه المحلي Local Similarity', color: palette.accent),
                      const SizedBox(height: 8),
                      _InfoPanel(
                        children: <Widget>[
                          _ArabicLine(label: 'أقرب بصمة', value: analysis.similarityMatch.signatureNameAr),
                          _ArabicLine(label: 'النوع', value: analysis.similarityMatch.signatureType),
                          _ArabicLine(label: 'd', value: analysis.similarityMatch.euclideanDistance.toStringAsFixed(4)),
                          _ArabicLine(label: 'Cosine', value: analysis.similarityMatch.cosineSimilarity.toStringAsFixed(4)),
                          _ArabicLine(label: 'القوة', value: analysis.similarityMatch.strengthAr),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _SectionTitle(title: 'إعدادات GPZ 7000 المقترحة', color: palette.accent),
                      const SizedBox(height: 8),
                      _InfoPanel(
                        children: <Widget>[
                          _ArabicLine(label: 'Ground Type', value: analysis.gpzRecommendation.groundType),
                          _ArabicLine(label: 'Gold Mode', value: analysis.gpzRecommendation.goldMode),
                          _ArabicLine(
                            label: 'Sensitivity',
                            value:
                                '${analysis.gpzRecommendation.sensitivityMin}–${analysis.gpzRecommendation.sensitivityMax}',
                          ),
                          _ArabicLine(label: 'Audio Smoothing', value: analysis.gpzRecommendation.audioSmoothing),
                          _ArabicLine(label: 'Swing', value: analysis.gpzRecommendation.swingSpeed),
                          const SizedBox(height: 8),
                          Text(
                            analysis.gpzRecommendation.arabicSummary,
                            style: const TextStyle(color: Colors.white70, height: 1.45, fontSize: 13.5),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _InfoPanel(
                        children: <Widget>[
                          _ArabicLine(label: 'تنبيه اقتصادي', value: 'الحسم النهائي يتطلب تحققاً حقلياً + Assay + QA/QC'),
                          _ArabicLine(label: 'إصدار Region Pack', value: analysis.packVersion),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.analysis, required this.palette});

  final CoordinateAnalysisResult analysis;
  final _SheetPalette palette;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: <Color>[palette.header, palette.header.withOpacity(0.78)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: palette.accent.withOpacity(0.55)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            children: <Widget>[
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: palette.accent.withOpacity(0.14),
                  border: Border.all(color: palette.accent, width: 2),
                ),
                alignment: Alignment.center,
                child: Icon(_statusIcon(analysis.engineResult.decisionStatus), color: palette.accent, size: 28),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      analysis.engineResult.decisionAr,
                      style: TextStyle(color: palette.accent, fontWeight: FontWeight.w900, fontSize: 20),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      analysis.nearestCell.nameAr,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            'الإحداثية: ${analysis.queryLatitude.toStringAsFixed(6)}, ${analysis.queryLongitude.toStringAsFixed(6)}',
            style: const TextStyle(color: Colors.white70, fontSize: 13),
          ),
          Text(
            'أقرب خلية: ${analysis.distanceMeters.toStringAsFixed(1)} متر',
            style: const TextStyle(color: Colors.white70, fontSize: 13),
          ),
        ],
      ),
    );
  }

  IconData _statusIcon(BouhDecisionStatus status) {
    switch (status) {
      case BouhDecisionStatus.targetBElite:
        return Icons.workspace_premium_rounded;
      case BouhDecisionStatus.candidate:
        return Icons.verified_rounded;
      case BouhDecisionStatus.hold:
      case BouhDecisionStatus.lowHold:
        return Icons.hourglass_top_rounded;
      case BouhDecisionStatus.reject:
        return Icons.gpp_bad_rounded;
    }
  }
}

class _ScoreStrip extends StatelessWidget {
  const _ScoreStrip({required this.analysis, required this.palette});

  final CoordinateAnalysisResult analysis;
  final _SheetPalette palette;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(child: _ScoreCard(label: 'IPI', value: analysis.engineResult.ipi, color: palette.accent)),
        const SizedBox(width: 10),
        Expanded(child: _ScoreCard(label: 'P-Score', value: analysis.engineResult.pScore, color: palette.accent)),
        const SizedBox(width: 10),
        Expanded(
          child: _ScoreCard(
            label: 'Active',
            value: analysis.nearestCell.activeIndicators250m.toDouble(),
            color: palette.accent,
            decimals: 0,
          ),
        ),
      ],
    );
  }
}

class _ScoreCard extends StatelessWidget {
  const _ScoreCard({required this.label, required this.value, required this.color, this.decimals = 1});

  final String label;
  final double value;
  final Color color;
  final int decimals;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Column(
        children: <Widget>[
          Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12)),
          const SizedBox(height: 4),
          Text(
            value.toStringAsFixed(decimals),
            style: TextStyle(color: color, fontSize: 20, fontWeight: FontWeight.w900),
          ),
        ],
      ),
    );
  }
}

class _MetricItem {
  const _MetricItem(this.label, this.value);
  final String label;
  final double value;
}

class _MetricGrid extends StatelessWidget {
  const _MetricGrid({required this.metrics});

  final List<_MetricItem> metrics;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: metrics
          .map(
            (metric) => Container(
              width: (MediaQuery.sizeOf(context).width - 52) / 2,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.26),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.white.withOpacity(0.10)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(metric.label, style: const TextStyle(color: Colors.white54, fontSize: 11)),
                  const SizedBox(height: 6),
                  Text(
                    metric.value.toStringAsFixed(4),
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16),
                  ),
                ],
              ),
            ),
          )
          .toList(growable: false),
    );
  }
}

class _GatesPanel extends StatelessWidget {
  const _GatesPanel({required this.analysis, required this.palette});

  final CoordinateAnalysisResult analysis;
  final _SheetPalette palette;

  @override
  Widget build(BuildContext context) {
    if (analysis.engineResult.triggeredGates.isEmpty && !analysis.engineResult.downgraded) {
      return _InfoPanel(
        children: <Widget>[
          Row(
            children: <Widget>[
              Icon(Icons.check_circle_rounded, color: palette.accent),
              const SizedBox(width: 8),
              const Expanded(
                child: Text('لم يتم تفعيل بوابات رفض صارمة.', style: TextStyle(color: Colors.white70)),
              ),
            ],
          ),
        ],
      );
    }

    return _InfoPanel(
      children: <Widget>[
        for (final gate in analysis.engineResult.triggeredGates)
          Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Icon(gate.effect == 'REJECT' ? Icons.dangerous_rounded : Icons.warning_rounded, color: palette.accent, size: 20),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    '${gate.code}: ${gate.nameAr} (${gate.effect})',
                    style: const TextStyle(color: Colors.white70, height: 1.35),
                  ),
                ),
              ],
            ),
          ),
        if (analysis.engineResult.downgraded)
          const Text(
            'تم خفض التصنيف لأن عدد المؤشرات النشطة داخل 250 متر أقل من 3.',
            style: TextStyle(color: Colors.white70, height: 1.35),
          ),
      ],
    );
  }
}

class _InfoPanel extends StatelessWidget {
  const _InfoPanel({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.30),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: children),
    );
  }
}

class _ArabicLine extends StatelessWidget {
  const _ArabicLine({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          SizedBox(
            width: 104,
            child: Text(label, style: const TextStyle(color: Colors.white54, fontSize: 12.5)),
          ),
          Expanded(
            child: Text(value, style: const TextStyle(color: Colors.white, fontSize: 13.5, fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title, required this.color});

  final String title;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Text(title, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 15.5));
  }
}

class _SheetPalette {
  const _SheetPalette({required this.background, required this.header, required this.accent});

  final Color background;
  final Color header;
  final Color accent;

  factory _SheetPalette.fromStatus(BouhDecisionStatus status) {
    switch (status) {
      case BouhDecisionStatus.reject:
        return const _SheetPalette(background: Color(0xFF190708), header: Color(0xFF5A0808), accent: Color(0xFFFF2D2D));
      case BouhDecisionStatus.hold:
      case BouhDecisionStatus.lowHold:
        return const _SheetPalette(background: Color(0xFF171006), header: Color(0xFF5B3B00), accent: Color(0xFFFFB300));
      case BouhDecisionStatus.candidate:
        return const _SheetPalette(background: Color(0xFF07140B), header: Color(0xFF0B4F22), accent: Color(0xFF44D17A));
      case BouhDecisionStatus.targetBElite:
        return const _SheetPalette(background: Color(0xFF16040A), header: Color(0xFF8B0000), accent: Color(0xFFFFD700));
    }
  }
}

class _GoldParticleField extends StatelessWidget {
  const _GoldParticleField();

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: CustomPaint(
        painter: _GoldParticlePainter(),
      ),
    );
  }
}

class _GoldParticlePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = const Color(0xFFFFD700).withOpacity(0.16);
    for (var i = 0; i < 52; i++) {
      final x = (math.sin(i * 12.9898) * 43758.5453).abs() % size.width;
      final y = (math.cos(i * 78.233) * 12345.6789).abs() % size.height;
      final radius = 1.2 + ((i % 5) * 0.42);
      canvas.drawCircle(Offset(x, y), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
