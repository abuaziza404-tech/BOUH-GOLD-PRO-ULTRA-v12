import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';

import '../../data/datasources/local_pack_datasource.dart';
import '../../data/repositories/analysis_repository.dart';
import '../../engines/bouh_supreme_engine.dart';
import '../widgets/analysis_bottom_sheet.dart';

class BouhMapScreen extends StatefulWidget {
  const BouhMapScreen({super.key});

  @override
  State<BouhMapScreen> createState() => _BouhMapScreenState();
}

class _BouhMapScreenState extends State<BouhMapScreen> {
  late final AnalysisRepository _repository;
  late final MapController _mapController;
  late Future<RegionPackBundle> _packFuture;
  Future<List<TargetPreview>>? _previewsFuture;
  StreamSubscription<Position>? _positionSubscription;
  Position? _currentPosition;
  TargetSortMode _sortMode = TargetSortMode.eliteFirst;
  bool _isAnalyzing = false;
  bool _isCachingTiles = false;
  String _cacheStatus = 'جاهز';

  static const List<double> _darkMatrix = <double>[
    0.42, 0.00, 0.00, 0.00, 0.00,
    0.00, 0.48, 0.00, 0.00, 0.00,
    0.00, 0.00, 0.58, 0.00, 0.00,
    0.00, 0.00, 0.00, 1.00, 0.00,
  ];

  @override
  void initState() {
    super.initState();
    _mapController = MapController();
    _repository = AnalysisRepository(localPackDataSource: LocalPackDataSource());
    _packFuture = _repository.getPack();
    _refreshPreviews();
    _startGpsTracking();
  }

  @override
  void dispose() {
    _positionSubscription?.cancel();
    _mapController.dispose();
    super.dispose();
  }

  void _refreshPreviews() {
    _previewsFuture = _repository.getTargetPreviews(
      sortMode: _sortMode,
      referenceLatitude: _currentPosition?.latitude,
      referenceLongitude: _currentPosition?.longitude,
    );
  }

  Future<void> _startGpsTracking() async {
    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) return;

    final enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) return;

    final last = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
    if (mounted) {
      setState(() {
        _currentPosition = last;
        _refreshPreviews();
      });
    }

    _positionSubscription = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.bestForNavigation,
        distanceFilter: 3,
      ),
    ).listen((position) {
      if (!mounted) return;
      setState(() {
        _currentPosition = position;
        _refreshPreviews();
      });
    });
  }

  Future<void> _handleMapTap(LatLng point) async {
    if (_isAnalyzing) return;
    setState(() => _isAnalyzing = true);
    try {
      final result = await _repository.analyzeCoordinate(latitude: point.latitude, longitude: point.longitude);
      if (!mounted) return;
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black.withOpacity(0.72),
        builder: (context) => DraggableScrollableSheet(
          initialChildSize: 0.78,
          minChildSize: 0.40,
          maxChildSize: 0.96,
          expand: false,
          builder: (context, scrollController) => AnalysisBottomSheet(analysis: result),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Directionality(textDirection: TextDirection.rtl, child: Text(error.toString())),
          backgroundColor: const Color(0xFF8B0000),
        ),
      );
    } finally {
      if (mounted) setState(() => _isAnalyzing = false);
    }
  }

  Future<void> _cacheVisibleExplorationZone(PackManifest manifest) async {
    if (_isCachingTiles) return;
    setState(() {
      _isCachingTiles = true;
      _cacheStatus = 'جاري حفظ بلاطات المنطقة...';
    });
    try {
      final center = _mapController.camera.center;
      final service = ExplorationTileCacheService(urlTemplate: manifest.tileUrlTemplate);
      final count = await service.cacheZone(
        center: center,
        zoomLevels: <int>[12, 13, 14, 15],
        radiusTiles: 2,
      );
      if (!mounted) return;
      setState(() => _cacheStatus = 'تم حفظ $count بلاطة محلية');
    } catch (error) {
      if (!mounted) return;
      setState(() => _cacheStatus = 'فشل التخزين: $error');
    } finally {
      if (mounted) setState(() => _isCachingTiles = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: FutureBuilder<RegionPackBundle>(
        future: _packFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return const Scaffold(
              backgroundColor: Color(0xFF121212),
              body: Center(child: CircularProgressIndicator(color: Color(0xFFFFD700))),
            );
          }
          if (snapshot.hasError || !snapshot.hasData) {
            return Scaffold(
              backgroundColor: const Color(0xFF121212),
              body: Center(
                child: Padding(
                  padding: const EdgeInsets.all(24),
                  child: Text(
                    'تعذر تحميل Region Pack: ${snapshot.error}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white, height: 1.5),
                  ),
                ),
              ),
            );
          }

          final pack = snapshot.data!;
          final manifest = pack.manifest;
          final center = LatLng(manifest.centerLatitude, manifest.centerLongitude);

          return Scaffold(
            backgroundColor: const Color(0xFF121212),
            body: Stack(
              children: <Widget>[
                FlutterMap(
                  mapController: _mapController,
                  options: MapOptions(
                    initialCenter: center,
                    initialZoom: 13,
                    minZoom: manifest.minZoom.toDouble(),
                    maxZoom: manifest.maxZoom.toDouble(),
                    interactionOptions: const InteractionOptions(
                      flags: InteractiveFlag.drag |
                          InteractiveFlag.pinchZoom |
                          InteractiveFlag.doubleTapZoom |
                          InteractiveFlag.scrollWheelZoom,
                    ),
                    onTap: (_, point) => _handleMapTap(point),
                  ),
                  children: <Widget>[
                    TileLayer(
                      urlTemplate: manifest.tileUrlTemplate,
                      userAgentPackageName: 'com.bouh.gold_pro_ultra',
                      maxZoom: manifest.maxZoom.toDouble(),
                      minZoom: manifest.minZoom.toDouble(),
                      tileProvider: NetworkTileProvider(),
                      tileBuilder: (context, tileWidget, tile) {
                        return ColorFiltered(
                          colorFilter: const ColorFilter.matrix(_darkMatrix),
                          child: tileWidget,
                        );
                      },
                    ),
                    CircleLayer(
                      circles: <CircleMarker>[
                        CircleMarker(
                          point: center,
                          radius: 2200,
                          useRadiusInMeter: true,
                          color: const Color(0xFFFFD700).withOpacity(0.06),
                          borderColor: const Color(0xFFFFD700).withOpacity(0.45),
                          borderStrokeWidth: 1.2,
                        ),
                      ],
                    ),
                    FutureBuilder<List<TargetPreview>>(
                      future: _previewsFuture,
                      builder: (context, previewSnapshot) {
                        final previews = previewSnapshot.data ?? const <TargetPreview>[];
                        return MarkerLayer(
                          markers: <Marker>[
                            for (final preview in previews)
                              Marker(
                                point: LatLng(preview.cell.latitude, preview.cell.longitude),
                                width: 42,
                                height: 42,
                                child: _TargetMarker(preview: preview),
                              ),
                            if (_currentPosition != null)
                              Marker(
                                point: LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
                                width: 46,
                                height: 46,
                                child: const _GpsMarker(),
                              ),
                          ],
                        );
                      },
                    ),
                  ],
                ),
                _TopDashboard(
                  sortMode: _sortMode,
                  cacheStatus: _cacheStatus,
                  isAnalyzing: _isAnalyzing,
                  isCachingTiles: _isCachingTiles,
                  onSortChanged: (mode) {
                    setState(() {
                      _sortMode = mode;
                      _refreshPreviews();
                    });
                  },
                  onCachePressed: () => _cacheVisibleExplorationZone(manifest),
                  onCenterGps: _currentPosition == null
                      ? null
                      : () {
                          _mapController.move(
                            LatLng(_currentPosition!.latitude, _currentPosition!.longitude),
                            math.max(_mapController.camera.zoom, 15.0),
                          );
                        },
                ),
                Positioned(
                  left: 14,
                  right: 14,
                  bottom: 18 + MediaQuery.paddingOf(context).bottom,
                  child: _BottomStatusPanel(
                    currentPosition: _currentPosition,
                    previewsFuture: _previewsFuture,
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _TopDashboard extends StatelessWidget {
  const _TopDashboard({
    required this.sortMode,
    required this.cacheStatus,
    required this.isAnalyzing,
    required this.isCachingTiles,
    required this.onSortChanged,
    required this.onCachePressed,
    required this.onCenterGps,
  });

  final TargetSortMode sortMode;
  final String cacheStatus;
  final bool isAnalyzing;
  final bool isCachingTiles;
  final ValueChanged<TargetSortMode> onSortChanged;
  final VoidCallback onCachePressed;
  final VoidCallback? onCenterGps;

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: MediaQuery.paddingOf(context).top + 12,
      left: 14,
      right: 14,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xEE121212),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.28)),
          boxShadow: <BoxShadow>[
            BoxShadow(color: Colors.black.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 8)),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Row(
              children: <Widget>[
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFD700).withOpacity(0.12),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFFFD700)),
                  ),
                  child: const Icon(Icons.radar_rounded, color: Color(0xFFFFD700)),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Text('BOUH GOLD PRO ULTRA v12.0', style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.w900, fontSize: 14)),
                      SizedBox(height: 2),
                      Text('بوح التضاريس — Dark Field Mode', style: TextStyle(color: Colors.white70, fontSize: 12)),
                    ],
                  ),
                ),
                if (isAnalyzing)
                  const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFFFFD700)),
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                _FilterChipButton(
                  selected: sortMode == TargetSortMode.eliteFirst,
                  label: 'Elite أولاً',
                  onTap: () => onSortChanged(TargetSortMode.eliteFirst),
                ),
                _FilterChipButton(
                  selected: sortMode == TargetSortMode.highestIpi,
                  label: 'أعلى IPI',
                  onTap: () => onSortChanged(TargetSortMode.highestIpi),
                ),
                _FilterChipButton(
                  selected: sortMode == TargetSortMode.highestPScore,
                  label: 'أعلى P-Score',
                  onTap: () => onSortChanged(TargetSortMode.highestPScore),
                ),
                _FilterChipButton(
                  selected: sortMode == TargetSortMode.nearest,
                  label: 'الأقرب',
                  onTap: () => onSortChanged(TargetSortMode.nearest),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: <Widget>[
                Expanded(
                  child: Text(cacheStatus, style: const TextStyle(color: Colors.white54, fontSize: 11.5), overflow: TextOverflow.ellipsis),
                ),
                IconButton(
                  onPressed: isCachingTiles ? null : onCachePressed,
                  tooltip: 'حفظ بلاطات المنطقة',
                  icon: Icon(isCachingTiles ? Icons.downloading_rounded : Icons.cloud_download_rounded, color: const Color(0xFFFFD700)),
                ),
                IconButton(
                  onPressed: onCenterGps,
                  tooltip: 'موقعي الحالي',
                  icon: Icon(Icons.my_location_rounded, color: onCenterGps == null ? Colors.white24 : const Color(0xFFFFD700)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _BottomStatusPanel extends StatelessWidget {
  const _BottomStatusPanel({required this.currentPosition, required this.previewsFuture});

  final Position? currentPosition;
  final Future<List<TargetPreview>>? previewsFuture;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<TargetPreview>>(
      future: previewsFuture,
      builder: (context, snapshot) {
        final previews = snapshot.data ?? const <TargetPreview>[];
        final nearest = previews.isEmpty ? null : previews.first;
        String distanceText = 'GPS غير مفعل';
        if (currentPosition != null && nearest != null && nearest.distanceMeters.isFinite) {
          distanceText = '${nearest.distanceMeters.toStringAsFixed(1)} متر إلى أقرب خلية';
        }
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: const Color(0xEE121212),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: Colors.white.withOpacity(0.10)),
          ),
          child: Row(
            children: <Widget>[
              const Icon(Icons.route_rounded, color: Color(0xFFFFD700)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  distanceText,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                ),
              ),
              const Text('اضغط على الخريطة للتحليل', style: TextStyle(color: Colors.white54, fontSize: 12)),
            ],
          ),
        );
      },
    );
  }
}

class _FilterChipButton extends StatelessWidget {
  const _FilterChipButton({required this.selected, required this.label, required this.onTap});

  final bool selected;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFFFFD700).withOpacity(0.18) : Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: selected ? const Color(0xFFFFD700) : Colors.white.withOpacity(0.10)),
        ),
        child: Text(label, style: TextStyle(color: selected ? const Color(0xFFFFD700) : Colors.white70, fontWeight: FontWeight.w700, fontSize: 12)),
      ),
    );
  }
}

class _TargetMarker extends StatelessWidget {
  const _TargetMarker({required this.preview});

  final TargetPreview preview;

  @override
  Widget build(BuildContext context) {
    final color = _colorForStatus(preview.engineResult.decisionStatus);
    return GestureDetector(
      onTap: () {
        final state = context.findAncestorStateOfType<_BouhMapScreenState>();
        state?._handleMapTap(LatLng(preview.cell.latitude, preview.cell.longitude));
      },
      child: Container(
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color.withOpacity(0.18),
          border: Border.all(color: color, width: 2.4),
          boxShadow: <BoxShadow>[BoxShadow(color: color.withOpacity(0.35), blurRadius: 16)],
        ),
        child: Center(
          child: Text(
            preview.engineResult.ipi.toStringAsFixed(0),
            style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w900),
          ),
        ),
      ),
    );
  }

  Color _colorForStatus(BouhDecisionStatus status) {
    switch (status) {
      case BouhDecisionStatus.reject:
        return const Color(0xFFFF2D2D);
      case BouhDecisionStatus.hold:
      case BouhDecisionStatus.lowHold:
        return const Color(0xFFFFB300);
      case BouhDecisionStatus.candidate:
        return const Color(0xFF44D17A);
      case BouhDecisionStatus.targetBElite:
        return const Color(0xFFFFD700);
    }
  }
}

class _GpsMarker extends StatelessWidget {
  const _GpsMarker();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: const Color(0xFF00B0FF).withOpacity(0.18),
        border: Border.all(color: const Color(0xFF00B0FF), width: 2),
        boxShadow: <BoxShadow>[BoxShadow(color: const Color(0xFF00B0FF).withOpacity(0.4), blurRadius: 18)],
      ),
      child: const Icon(Icons.navigation_rounded, color: Color(0xFF00B0FF), size: 22),
    );
  }
}

class ExplorationTileCacheService {
  ExplorationTileCacheService({required this.urlTemplate, http.Client? client}) : _client = client ?? http.Client();

  final String urlTemplate;
  final http.Client _client;

  Future<int> cacheZone({
    required LatLng center,
    required List<int> zoomLevels,
    int radiusTiles = 2,
  }) async {
    final root = await getApplicationDocumentsDirectory();
    var saved = 0;
    for (final zoom in zoomLevels) {
      final centerTile = _latLonToTile(center.latitude, center.longitude, zoom);
      for (var x = centerTile.x - radiusTiles; x <= centerTile.x + radiusTiles; x++) {
        for (var y = centerTile.y - radiusTiles; y <= centerTile.y + radiusTiles; y++) {
          if (x < 0 || y < 0) continue;
          final file = File('${root.path}/bouh_tiles/$zoom/$x/$y.png');
          if (await file.exists() && await file.length() > 512) {
            saved++;
            continue;
          }
          await file.parent.create(recursive: true);
          final uri = Uri.parse(_tileUrl(zoom: zoom, x: x, y: y));
          final response = await _client.get(
            uri,
            headers: const <String, String>{'User-Agent': 'BOUH-GOLD-PRO-ULTRA-v12/1.0'},
          ).timeout(const Duration(seconds: 12));
          if (response.statusCode >= 200 && response.statusCode < 300 && response.bodyBytes.length > 512) {
            await file.writeAsBytes(response.bodyBytes, flush: true);
            saved++;
          }
        }
      }
    }
    return saved;
  }

  String _tileUrl({required int zoom, required int x, required int y}) {
    final subdomains = const <String>['a', 'b', 'c'];
    final s = subdomains[(x + y + zoom).abs() % subdomains.length];
    return urlTemplate
        .replaceAll('{s}', s)
        .replaceAll('{z}', zoom.toString())
        .replaceAll('{x}', x.toString())
        .replaceAll('{y}', y.toString());
  }

  _TileXY _latLonToTile(double lat, double lon, int zoom) {
    final latRad = lat * math.pi / 180.0;
    final n = math.pow(2.0, zoom).toDouble();
    final x = ((lon + 180.0) / 360.0 * n).floor();
    final y = ((1.0 - (math.log(math.tan(latRad) + (1.0 / math.cos(latRad))) / math.pi)) / 2.0 * n).floor();
    return _TileXY(x, y);
  }
}

class _TileXY {
  const _TileXY(this.x, this.y);
  final int x;
  final int y;
}
