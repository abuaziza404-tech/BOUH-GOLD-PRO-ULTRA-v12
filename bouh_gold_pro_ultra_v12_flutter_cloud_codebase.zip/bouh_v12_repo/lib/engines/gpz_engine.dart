class GpzRecommendation {
  const GpzRecommendation({
    required this.profileCode,
    required this.groundType,
    required this.goldMode,
    required this.sensitivityMin,
    required this.sensitivityMax,
    required this.audioSmoothing,
    required this.swingSpeed,
    required this.arabicSummary,
    required this.riskLevel,
  });

  final String profileCode;
  final String groundType;
  final String goldMode;
  final int sensitivityMin;
  final int sensitivityMax;
  final String audioSmoothing;
  final String swingSpeed;
  final String arabicSummary;
  final String riskLevel;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'profile_code': profileCode,
        'ground_type': groundType,
        'gold_mode': goldMode,
        'sensitivity_min': sensitivityMin,
        'sensitivity_max': sensitivityMax,
        'audio_smoothing': audioSmoothing,
        'swing_speed': swingSpeed,
        'risk_level': riskLevel,
        'arabic_summary': arabicSummary,
      };
}

class GpzEngine {
  GpzEngine._();

  static GpzRecommendation recommend({
    required double magneticRisk,
    required double quartzIndex,
    bool quartzHigh = false,
  }) {
    final risk = magneticRisk.clamp(0.0, 1.0).toDouble();
    final highQuartz = quartzHigh || quartzIndex >= 1.08;

    if (risk > 0.75) {
      return const GpzRecommendation(
        profileCode: 'GPZ_HIGH_MAGNETIC_SEVERE',
        groundType: 'Severe / Difficult',
        goldMode: 'High Yield',
        sensitivityMin: 8,
        sensitivityMax: 11,
        audioSmoothing: 'Low / On',
        swingSpeed: 'Slow Swing Strategy',
        riskLevel: 'مرتفع',
        arabicSummary:
            'خطر مغناطيسي مرتفع: استخدم Ground Type: Severe/Difficult، Gold Mode: High Yield، الحساسية 8–11، Audio Smoothing Low/On، وسرعة مسح بطيئة لتقليل ضجيج اللاتريت/البازلت.',
      );
    }

    if (risk < 0.45 && highQuartz) {
      return const GpzRecommendation(
        profileCode: 'GPZ_LOW_MAGNETIC_HIGH_QUARTZ_DEEP',
        groundType: 'Normal',
        goldMode: 'General / Deep',
        sensitivityMin: 12,
        sensitivityMax: 16,
        audioSmoothing: 'Off',
        swingSpeed: 'Controlled Medium-Slow Swing',
        riskLevel: 'منخفض',
        arabicSummary:
            'أرض هادئة مع كوارتز/سيليكا واضح: استخدم Ground Type: Normal، Gold Mode: General/Deep، الحساسية 12–16، Audio Smoothing Off لتعظيم العمق في جيوب الصخر القريبة من السطح.',
      );
    }

    if (risk >= 0.45 && risk <= 0.75 && highQuartz) {
      return const GpzRecommendation(
        profileCode: 'GPZ_MIXED_GROUND_QUARTZ_CONTROL',
        groundType: 'Difficult',
        goldMode: 'General',
        sensitivityMin: 10,
        sensitivityMax: 13,
        audioSmoothing: 'Low',
        swingSpeed: 'Slow-To-Medium Swing',
        riskLevel: 'متوسط',
        arabicSummary:
            'أرض مختلطة مع بصمة كوارتز: ابدأ بـ Difficult + General، الحساسية 10–13، Audio Smoothing Low، ثم ارفع الحساسية تدريجياً إذا بقيت الإشارة مستقرة.',
      );
    }

    return const GpzRecommendation(
      profileCode: 'GPZ_RECON_BALANCED',
      groundType: 'Difficult',
      goldMode: 'High Yield',
      sensitivityMin: 9,
      sensitivityMax: 12,
      audioSmoothing: 'Low / On',
      swingSpeed: 'Slow Recon Swing',
      riskLevel: 'استطلاعي',
      arabicSummary:
          'لا توجد نافذة كوارتز عميقة مؤكدة أو الأرض غير هادئة تماماً: استخدم إعداداً استطلاعياً محافظاً، وركز على تكرار الإشارة قبل الحفر.',
    );
  }
}
