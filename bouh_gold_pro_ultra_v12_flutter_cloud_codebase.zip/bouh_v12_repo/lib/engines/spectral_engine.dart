enum SensorType { sentinel2, landsat89, aster }

class SpectralMetrics {
  const SpectralMetrics({
    required this.sensorType,
    required this.blue,
    required this.red,
    required this.nir,
    required this.swir1,
    required this.swir2,
    required this.ironIndex,
    required this.quartzIndex,
    required this.alterationIndex,
    required this.ndmi,
    required this.spectralScore,
    required this.hasIronOxide,
    required this.hasQuartzSilica,
    required this.hasClaySwir,
    required this.isValid,
  });

  final SensorType sensorType;
  final double blue;
  final double red;
  final double nir;
  final double swir1;
  final double swir2;
  final double ironIndex;
  final double quartzIndex;
  final double alterationIndex;
  final double ndmi;
  final double spectralScore;
  final bool hasIronOxide;
  final bool hasQuartzSilica;
  final bool hasClaySwir;
  final bool isValid;

  List<double> get normalizedVector5 => <double>[
        _normalizeRatio(ironIndex, 0.65, 2.20),
        _normalizeRatio(quartzIndex, 0.70, 2.10),
        _normalizeRatio(alterationIndex, 0.50, 2.60),
        ((ndmi + 1.0) / 2.0).clamp(0.0, 1.0).toDouble(),
        spectralScore.clamp(0.0, 1.0).toDouble(),
      ];

  Map<String, dynamic> toJson() => <String, dynamic>{
        'sensor_type': sensorType.name,
        'B2_blue': blue,
        'B4_red': red,
        'B8_nir': nir,
        'B11_swir1': swir1,
        'B12_swir2': swir2,
        'iron_index': ironIndex,
        'quartz_index': quartzIndex,
        'alteration_index': alterationIndex,
        'ndmi': ndmi,
        'spectral_score': spectralScore,
        'has_iron_oxide': hasIronOxide,
        'has_quartz_silica': hasQuartzSilica,
        'has_clay_swir': hasClaySwir,
        'is_valid': isValid,
      };
}

class SpectralEngine {
  SpectralEngine._();

  static SpectralMetrics analyze({
    required Map<String, double> bands,
    SensorType sensorType = SensorType.sentinel2,
  }) {
    final blue = _band(bands, <String>['B2', 'b2', 'blue', 'B02']);
    final red = _band(bands, <String>['B4', 'b4', 'red', 'B04']);
    final nir = _band(bands, <String>['B8', 'b8', 'nir', 'B08']);
    final swir1 = _band(bands, <String>['B11', 'b11', 'swir1', 'SWIR1']);
    final swir2 = _band(bands, <String>['B12', 'b12', 'swir2', 'SWIR2']);

    final isValid = blue > 0.0 && red > 0.0 && nir > 0.0 && swir1 > 0.0 && swir2 > 0.0;
    final ironIndex = _safeDivide(red, blue);
    final quartzIndex = _safeDivide(swir1, swir2);
    final alterationIndex = _safeDivide(swir1 + swir2, nir);
    final ndmi = _safeDivide(nir - swir1, nir + swir1).clamp(-1.0, 1.0).toDouble();

    final ironScore = _normalizeRatio(ironIndex, 0.95, 1.75);
    final quartzScore = _normalizeRatio(quartzIndex, 0.92, 1.65);
    final alterationScore = _normalizeRatio(alterationIndex, 0.85, 2.20);
    final drynessScore = (1.0 - ((ndmi + 1.0) / 2.0)).clamp(0.0, 1.0).toDouble();

    final spectralScore = isValid
        ? ((0.25 * ironScore) + (0.35 * quartzScore) + (0.30 * alterationScore) + (0.10 * drynessScore))
            .clamp(0.0, 1.0)
            .toDouble()
        : 0.0;

    return SpectralMetrics(
      sensorType: sensorType,
      blue: blue,
      red: red,
      nir: nir,
      swir1: swir1,
      swir2: swir2,
      ironIndex: ironIndex,
      quartzIndex: quartzIndex,
      alterationIndex: alterationIndex,
      ndmi: ndmi,
      spectralScore: spectralScore,
      hasIronOxide: ironIndex >= 1.15,
      hasQuartzSilica: quartzIndex >= 1.08,
      hasClaySwir: alterationIndex >= 1.12 || quartzIndex >= 1.08,
      isValid: isValid,
    );
  }

  static SensorType parseSensorType(String value) {
    switch (value.trim().toLowerCase()) {
      case 'landsat':
      case 'landsat8':
      case 'landsat9':
      case 'landsat89':
        return SensorType.landsat89;
      case 'aster':
        return SensorType.aster;
      case 'sentinel':
      case 'sentinel2':
      default:
        return SensorType.sentinel2;
    }
  }

  static double _band(Map<String, double> bands, List<String> keys) {
    for (final key in keys) {
      final value = bands[key];
      if (value != null && value.isFinite) return value;
    }
    return 0.0;
  }

  static double _safeDivide(double numerator, double denominator) {
    if (denominator.abs() < 1.0e-12) return 0.0;
    final value = numerator / denominator;
    if (!value.isFinite) return 0.0;
    return value;
  }
}

double _normalizeRatio(double value, double low, double high) {
  if (!value.isFinite || high <= low) return 0.0;
  return ((value - low) / (high - low)).clamp(0.0, 1.0).toDouble();
}
