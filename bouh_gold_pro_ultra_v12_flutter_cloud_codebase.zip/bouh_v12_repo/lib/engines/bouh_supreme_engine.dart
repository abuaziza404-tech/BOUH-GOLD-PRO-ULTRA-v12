import '../data/datasources/local_pack_datasource.dart';
import 'spectral_engine.dart';

enum BouhDecisionStatus { targetBElite, candidate, hold, lowHold, reject }

class BouhAnalysisInput {
  const BouhAnalysisInput({
    required this.spectral,
    required this.structureScore,
    required this.patternScore,
    required this.fieldEvidenceScore,
    required this.activeIndicators250m,
  });

  final SpectralMetrics spectral;
  final double structureScore;
  final double patternScore;
  final double fieldEvidenceScore;
  final int activeIndicators250m;
}

class TriggeredGate {
  const TriggeredGate({required this.code, required this.nameAr, required this.effect});

  final String code;
  final String nameAr;
  final String effect;
}

class BouhEngineResult {
  const BouhEngineResult({
    required this.ipi,
    required this.pScore,
    required this.decisionStatus,
    required this.decisionAr,
    required this.triggeredGates,
    required this.downgraded,
    required this.requiresFieldValidation,
  });

  final double ipi;
  final double pScore;
  final BouhDecisionStatus decisionStatus;
  final String decisionAr;
  final List<TriggeredGate> triggeredGates;
  final bool downgraded;
  final bool requiresFieldValidation;

  bool get isReject => decisionStatus == BouhDecisionStatus.reject;
  bool get isHold => decisionStatus == BouhDecisionStatus.hold || decisionStatus == BouhDecisionStatus.lowHold;
  bool get isElite => decisionStatus == BouhDecisionStatus.targetBElite;
}

class BouhSupremeEngine {
  BouhSupremeEngine._();

  static BouhEngineResult analyze({
    required BouhAnalysisInput input,
    required KillMatrix killMatrix,
  }) {
    final s = input.structureScore.clamp(0.0, 1.0).toDouble();
    final a = input.spectral.spectralScore.clamp(0.0, 1.0).toDouble();
    final p = input.patternScore.clamp(0.0, 1.0).toDouble();
    final f = input.fieldEvidenceScore.clamp(0.0, 1.0).toDouble();
    final c = input.spectral.hasClaySwir ? a : 0.0;
    final iron = input.spectral.hasIronOxide ? _ratioScore(input.spectral.ironIndex, 1.0, 1.80) : 0.0;
    final quartz = input.spectral.hasQuartzSilica ? _ratioScore(input.spectral.quartzIndex, 1.0, 1.70) : 0.0;

    final ipi = 100.0 * ((0.35 * s) + (0.30 * a) + (0.20 * p) + (0.15 * f));
    final pScore = 100.0 * ((0.35 * s) + (0.25 * c) + (0.20 * iron) + (0.20 * quartz));

    final triggered = <TriggeredGate>[];
    void trigger(String code, String fallbackName, String effect) {
      final gate = killMatrix.gateByCode(code);
      if (gate == null || gate.enabled) {
        triggered.add(TriggeredGate(code: code, nameAr: gate?.nameAr ?? fallbackName, effect: gate?.effect ?? effect));
      }
    }

    final hasStructure = s > 0.05;
    final hasPattern = p > 0.05;
    final hasSwir = input.spectral.hasClaySwir || input.spectral.hasQuartzSilica;
    final feoxAlone = input.spectral.hasIronOxide && !hasSwir;
    final spectralAlone = input.spectral.spectralScore > 0.25 && (!hasStructure || !hasPattern);

    if (!hasStructure) trigger('G01_NO_STRUCTURE', 'لا توجد بنية جيولوجية حاكمة', 'REJECT');
    if (!hasPattern) trigger('G02_NO_PATTERN', 'لا يوجد نمط هندسي أو عنقودي داعم', 'REJECT');
    if (!hasSwir) trigger('G03_NO_SWIR', 'لا توجد بوابة SWIR/Clay/Silica مؤكدة', 'HOLD');
    if (feoxAlone) trigger('G04_FEOX_ALONE', 'أكسيد الحديد منفرداً غير كافٍ', 'REJECT');
    if (spectralAlone) trigger('G05_SPECTRAL_ALONE', 'إشارة طيفية بلا بنية أو نمط', 'REJECT');

    final hasRejectGate = triggered.any((gate) => gate.effect.toUpperCase() == 'REJECT');
    final hasHoldGate = triggered.any((gate) => gate.effect.toUpperCase() == 'HOLD');
    final needsDowngrade = input.activeIndicators250m < 3;

    BouhDecisionStatus status;
    if (hasRejectGate) {
      status = BouhDecisionStatus.reject;
    } else if (hasHoldGate) {
      status = ipi >= 55.0 ? BouhDecisionStatus.hold : BouhDecisionStatus.lowHold;
    } else if (ipi >= 85.0) {
      status = BouhDecisionStatus.targetBElite;
    } else if (ipi >= 70.0) {
      status = BouhDecisionStatus.candidate;
    } else if (ipi >= 55.0) {
      status = BouhDecisionStatus.hold;
    } else if (ipi >= 35.0) {
      status = BouhDecisionStatus.lowHold;
    } else {
      status = BouhDecisionStatus.reject;
    }

    if (!hasRejectGate && needsDowngrade) {
      status = _downgrade(status);
    }

    return BouhEngineResult(
      ipi: double.parse(ipi.clamp(0.0, 100.0).toStringAsFixed(2)),
      pScore: double.parse(pScore.clamp(0.0, 100.0).toStringAsFixed(2)),
      decisionStatus: status,
      decisionAr: _decisionArabic(status),
      triggeredGates: triggered,
      downgraded: needsDowngrade && !hasRejectGate,
      requiresFieldValidation: true,
    );
  }

  static BouhDecisionStatus _downgrade(BouhDecisionStatus status) {
    switch (status) {
      case BouhDecisionStatus.targetBElite:
        return BouhDecisionStatus.candidate;
      case BouhDecisionStatus.candidate:
        return BouhDecisionStatus.hold;
      case BouhDecisionStatus.hold:
        return BouhDecisionStatus.lowHold;
      case BouhDecisionStatus.lowHold:
        return BouhDecisionStatus.reject;
      case BouhDecisionStatus.reject:
        return BouhDecisionStatus.reject;
    }
  }

  static String _decisionArabic(BouhDecisionStatus status) {
    switch (status) {
      case BouhDecisionStatus.targetBElite:
        return 'TARGET-B ELITE';
      case BouhDecisionStatus.candidate:
        return 'مرشح قوي Candidate';
      case BouhDecisionStatus.hold:
        return 'HOLD — يحتاج تأكيد SWIR/حقل';
      case BouhDecisionStatus.lowHold:
        return 'Low HOLD — أولوية منخفضة';
      case BouhDecisionStatus.reject:
        return 'REJECT — مرفوض بمصفوفة القتل';
    }
  }

  static double _ratioScore(double value, double low, double high) {
    if (high <= low || !value.isFinite) return 0.0;
    return ((value - low) / (high - low)).clamp(0.0, 1.0).toDouble();
  }
}
