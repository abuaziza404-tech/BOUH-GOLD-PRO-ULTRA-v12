import 'dart:math' as math;

import '../data/datasources/local_pack_datasource.dart';

class SimilarityMatch {
  const SimilarityMatch({
    required this.signatureId,
    required this.signatureNameAr,
    required this.signatureType,
    required this.euclideanDistance,
    required this.cosineSimilarity,
    required this.strengthAr,
  });

  final String signatureId;
  final String signatureNameAr;
  final String signatureType;
  final double euclideanDistance;
  final double cosineSimilarity;
  final String strengthAr;

  Map<String, dynamic> toJson() => <String, dynamic>{
        'signature_id': signatureId,
        'signature_name_ar': signatureNameAr,
        'signature_type': signatureType,
        'euclidean_distance_d': euclideanDistance,
        'cosine_similarity': cosineSimilarity,
        'strength_ar': strengthAr,
      };
}

class SimilarityEngine {
  SimilarityEngine._();

  static const List<KnownSignature> fallbackGoldQuartzSignatures = <KnownSignature>[
    KnownSignature(
      id: 'ARIAB_GOLD_QUARTZ_NORM_01',
      nameAr: 'بصمة كوارتز-ذهب أرياب المعيارية',
      type: 'gold_quartz_vein',
      vector: <double>[0.78, 0.82, 0.74, 0.34, 0.79],
      weight: 1.0,
    ),
    KnownSignature(
      id: 'GEBEIT_SHEAR_QUARTZ_02',
      nameAr: 'بصمة كوارتز قصّية - جبيت/سنكات',
      type: 'shear_hosted_quartz',
      vector: <double>[0.62, 0.88, 0.81, 0.29, 0.84],
      weight: 1.0,
    ),
    KnownSignature(
      id: 'HASHAY_GOSSAN_SILICA_03',
      nameAr: 'بصمة جوسان-سيليكا هاشاي',
      type: 'gossan_silica_cap',
      vector: <double>[0.91, 0.63, 0.77, 0.25, 0.72],
      weight: 0.92,
    ),
  ];

  static SimilarityMatch bestMatch({
    required List<double> sampleVector5,
    List<KnownSignature> signatures = fallbackGoldQuartzSignatures,
  }) {
    final vector = _normalizeVectorLength(sampleVector5, 5);
    final usableSignatures = signatures.isEmpty ? fallbackGoldQuartzSignatures : signatures;
    SimilarityMatch? best;

    for (final signature in usableSignatures) {
      final signatureVector = _normalizeVectorLength(signature.vector, 5);
      final d = euclideanDistance(vector, signatureVector);
      final cosine = cosineSimilarity(vector, signatureVector);
      final weightedD = d / math.max(0.0001, signature.weight);
      final match = SimilarityMatch(
        signatureId: signature.id,
        signatureNameAr: signature.nameAr,
        signatureType: signature.type,
        euclideanDistance: double.parse(weightedD.toStringAsFixed(6)),
        cosineSimilarity: double.parse(cosine.toStringAsFixed(6)),
        strengthAr: classifyDistanceArabic(weightedD),
      );
      if (best == null || match.euclideanDistance < best.euclideanDistance) {
        best = match;
      }
    }

    return best!;
  }

  static double euclideanDistance(List<double> a, List<double> b) {
    final left = _normalizeVectorLength(a, math.max(a.length, b.length));
    final right = _normalizeVectorLength(b, math.max(a.length, b.length));
    var sum = 0.0;
    for (var i = 0; i < left.length; i++) {
      final diff = left[i] - right[i];
      sum += diff * diff;
    }
    return math.sqrt(sum);
  }

  static double cosineSimilarity(List<double> a, List<double> b) {
    final left = _normalizeVectorLength(a, math.max(a.length, b.length));
    final right = _normalizeVectorLength(b, math.max(a.length, b.length));
    var dot = 0.0;
    var normA = 0.0;
    var normB = 0.0;
    for (var i = 0; i < left.length; i++) {
      dot += left[i] * right[i];
      normA += left[i] * left[i];
      normB += right[i] * right[i];
    }
    if (normA <= 1.0e-12 || normB <= 1.0e-12) return 0.0;
    return (dot / (math.sqrt(normA) * math.sqrt(normB))).clamp(-1.0, 1.0).toDouble();
  }

  static String classifyDistanceArabic(double d) {
    if (d < 0.15) return 'تشابه قوي جداً';
    if (d < 0.30) return 'تشابه جيد';
    if (d < 0.45) return 'تشابه متوسط';
    return 'تشابه ضعيف';
  }

  static List<double> _normalizeVectorLength(List<double> vector, int length) {
    final out = List<double>.filled(length, 0.0);
    for (var i = 0; i < math.min(length, vector.length); i++) {
      final value = vector[i];
      out[i] = value.isFinite ? value.clamp(0.0, 1.0).toDouble() : 0.0;
    }
    return out;
  }
}
