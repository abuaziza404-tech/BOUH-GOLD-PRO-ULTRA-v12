import 'dart:async';
import 'dart:convert';
import 'dart:isolate';

import 'package:flutter/services.dart' show rootBundle;

class LocalPackDataSource {
  LocalPackDataSource({
    this.manifestAssetPath = 'assets/packs/red_sea_hills/pack_manifest.json',
    this.killMatrixAssetPath = 'assets/packs/red_sea_hills/kill_matrix.json',
  });

  final String manifestAssetPath;
  final String killMatrixAssetPath;

  Future<RegionPackBundle> loadRedSeaHillsPack() async {
    final manifestFuture = _loadJsonMap(manifestAssetPath);
    final killMatrixFuture = _loadJsonMap(killMatrixAssetPath);
    final responses = await Future.wait<Map<String, dynamic>>(<Future<Map<String, dynamic>>>[
      manifestFuture,
      killMatrixFuture,
    ]);
    return RegionPackBundle(
      manifest: PackManifest.fromJson(responses[0]),
      killMatrix: KillMatrix.fromJson(responses[1]),
      loadedAt: DateTime.now().toUtc(),
    );
  }

  Stream<RegionPackLoadState> streamRedSeaHillsPack() async* {
    yield const RegionPackLoadState.loading(message: 'جاري تحميل حزمة تلال البحر الأحمر');
    try {
      final pack = await loadRedSeaHillsPack();
      yield RegionPackLoadState.ready(pack: pack);
    } catch (error, stackTrace) {
      yield RegionPackLoadState.failed(error: error, stackTrace: stackTrace);
    }
  }

  Future<Map<String, dynamic>> _loadJsonMap(String assetPath) async {
    final jsonText = await rootBundle.loadString(assetPath, cache: true);
    final decoded = await Isolate.run<dynamic>(() => jsonDecode(jsonText));
    if (decoded is Map<String, dynamic>) return decoded;
    if (decoded is Map) return decoded.map((key, value) => MapEntry(key.toString(), value));
    throw FormatException('Invalid JSON root in $assetPath: expected object');
  }
}

class RegionPackLoadState {
  const RegionPackLoadState._({this.pack, this.message, this.error, this.stackTrace});

  const RegionPackLoadState.loading({required String message}) : this._(message: message);

  const RegionPackLoadState.ready({required RegionPackBundle pack}) : this._(pack: pack);

  const RegionPackLoadState.failed({required Object error, required StackTrace stackTrace})
      : this._(error: error, stackTrace: stackTrace);

  final RegionPackBundle? pack;
  final String? message;
  final Object? error;
  final StackTrace? stackTrace;

  bool get isLoading => message != null && pack == null && error == null;
  bool get isReady => pack != null;
  bool get isFailed => error != null;
}

class RegionPackBundle {
  const RegionPackBundle({
    required this.manifest,
    required this.killMatrix,
    required this.loadedAt,
  });

  final PackManifest manifest;
  final KillMatrix killMatrix;
  final DateTime loadedAt;
}

class PackManifest {
  const PackManifest({
    required this.packId,
    required this.nameAr,
    required this.nameEn,
    required this.version,
    required this.regionCode,
    required this.centerLatitude,
    required this.centerLongitude,
    required this.minZoom,
    required this.maxZoom,
    required this.tileUrlTemplate,
    required this.boundingBox,
    required this.gridData,
    required this.knownSignatures,
    required this.metadata,
  });

  final String packId;
  final String nameAr;
  final String nameEn;
  final String version;
  final String regionCode;
  final double centerLatitude;
  final double centerLongitude;
  final int minZoom;
  final int maxZoom;
  final String tileUrlTemplate;
  final BoundingBox boundingBox;
  final List<RegionGridCell> gridData;
  final List<KnownSignature> knownSignatures;
  final Map<String, dynamic> metadata;

  factory PackManifest.fromJson(Map<String, dynamic> json) {
    final center = _asMap(json['center']);
    final mapTiles = _asMap(json['map_tiles']);
    final gridRaw = json['grid_data'] ?? json['cells'] ?? json['grid_index'];
    final signaturesRaw = json['known_signatures'];
    final gridList = gridRaw is List ? gridRaw : const <dynamic>[];
    final signaturesList = signaturesRaw is List ? signaturesRaw : const <dynamic>[];
    return PackManifest(
      packId: _string(json['pack_id'] ?? json['id'], 'red_sea_hills_v12'),
      nameAr: _string(json['name_ar'], 'بوح التضاريس - تلال البحر الأحمر'),
      nameEn: _string(json['name_en'], 'BOUH Red Sea Hills Region Pack'),
      version: _string(json['version'], '12.0.0'),
      regionCode: _string(json['region_code'], 'RED_SEA_HILLS'),
      centerLatitude: _double(center['lat'] ?? json['center_lat'], 19.046017),
      centerLongitude: _double(center['lon'] ?? center['lng'] ?? json['center_lon'], 37.323876),
      minZoom: _int(mapTiles['min_zoom'], 5),
      maxZoom: _int(mapTiles['max_zoom'], 18),
      tileUrlTemplate: _string(
        mapTiles['url_template'],
        'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
      ),
      boundingBox: BoundingBox.fromJson(_asMap(json['bbox'] ?? json['bounding_box'])),
      gridData: gridList.map((item) => RegionGridCell.fromJson(_asMap(item))).toList(growable: false),
      knownSignatures: signaturesList.map((item) => KnownSignature.fromJson(_asMap(item))).toList(growable: false),
      metadata: _asMap(json['metadata']),
    );
  }
}

class BoundingBox {
  const BoundingBox({
    required this.minLat,
    required this.minLon,
    required this.maxLat,
    required this.maxLon,
  });

  final double minLat;
  final double minLon;
  final double maxLat;
  final double maxLon;

  factory BoundingBox.fromJson(Map<String, dynamic> json) => BoundingBox(
        minLat: _double(json['min_lat'] ?? json['south'], 18.70),
        minLon: _double(json['min_lon'] ?? json['west'], 36.65),
        maxLat: _double(json['max_lat'] ?? json['north'], 20.10),
        maxLon: _double(json['max_lon'] ?? json['east'], 37.95),
      );

  bool contains(double lat, double lon) => lat >= minLat && lat <= maxLat && lon >= minLon && lon <= maxLon;
}

class RegionGridCell {
  const RegionGridCell({
    required this.id,
    required this.nameAr,
    required this.latitude,
    required this.longitude,
    required this.sensorType,
    required this.bands,
    required this.structureScore,
    required this.patternScore,
    required this.fieldEvidenceScore,
    required this.activeIndicators250m,
    required this.magneticRisk,
    required this.terrainScore,
    required this.clusterDensity,
    required this.properties,
  });

  final String id;
  final String nameAr;
  final double latitude;
  final double longitude;
  final String sensorType;
  final Map<String, double> bands;
  final double structureScore;
  final double patternScore;
  final double fieldEvidenceScore;
  final int activeIndicators250m;
  final double magneticRisk;
  final double terrainScore;
  final double clusterDensity;
  final Map<String, dynamic> properties;

  factory RegionGridCell.fromJson(Map<String, dynamic> json) {
    final bandsMap = _asMap(json['bands'] ?? json['spectral'] ?? json['sensor_bands']);
    return RegionGridCell(
      id: _string(json['id'] ?? json['cell_id'], 'cell_${json.hashCode}'),
      nameAr: _string(json['name_ar'] ?? json['label_ar'] ?? json['name'], 'خلية استكشاف'),
      latitude: _double(json['lat'] ?? json['latitude'] ?? json['center_lat'], 0.0),
      longitude: _double(json['lon'] ?? json['lng'] ?? json['longitude'] ?? json['center_lon'], 0.0),
      sensorType: _string(json['sensor_type'] ?? json['sensor'], 'sentinel2'),
      bands: bandsMap.map((key, value) => MapEntry(key.toString(), _double(value, 0.0))),
      structureScore: _normalizedScore(json['structure_score'] ?? json['S'] ?? json['structure']),
      patternScore: _normalizedScore(json['pattern_score'] ?? json['P'] ?? json['pattern']),
      fieldEvidenceScore: _normalizedScore(json['field_score'] ?? json['F'] ?? json['field_evidence']),
      activeIndicators250m: _int(json['active_indicators_250m'] ?? json['active_indicators'], 0),
      magneticRisk: _normalizedScore(json['magnetic_risk'] ?? json['magnetic_ground_risk']),
      terrainScore: _normalizedScore(json['terrain_score'] ?? json['terrain']),
      clusterDensity: _normalizedScore(json['cluster_density'] ?? json['cluster']),
      properties: _asMap(json['properties']),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name_ar': nameAr,
        'lat': latitude,
        'lon': longitude,
        'sensor_type': sensorType,
        'bands': bands,
        'structure_score': structureScore,
        'pattern_score': patternScore,
        'field_score': fieldEvidenceScore,
        'active_indicators_250m': activeIndicators250m,
        'magnetic_risk': magneticRisk,
        'terrain_score': terrainScore,
        'cluster_density': clusterDensity,
        'properties': properties,
      };
}

class KnownSignature {
  const KnownSignature({
    required this.id,
    required this.nameAr,
    required this.type,
    required this.vector,
    required this.weight,
  });

  final String id;
  final String nameAr;
  final String type;
  final List<double> vector;
  final double weight;

  factory KnownSignature.fromJson(Map<String, dynamic> json) {
    final vectorRaw = json['vector'] ?? json['spectral_vector'] ?? const <dynamic>[];
    final list = vectorRaw is List ? vectorRaw.map((e) => _double(e, 0.0)).toList(growable: false) : <double>[];
    return KnownSignature(
      id: _string(json['id'], 'signature_${json.hashCode}'),
      nameAr: _string(json['name_ar'] ?? json['name'], 'بصمة كوارتز-ذهب'),
      type: _string(json['type'], 'gold_quartz_vein'),
      vector: list,
      weight: _normalizedScore(json['weight'] ?? 1.0),
    );
  }

  Map<String, dynamic> toJson() => <String, dynamic>{
        'id': id,
        'name_ar': nameAr,
        'type': type,
        'vector': vector,
        'weight': weight,
      };
}

class KillMatrix {
  const KillMatrix({required this.version, required this.hardGates, required this.downgradeRules});

  final String version;
  final List<KillGate> hardGates;
  final List<DowngradeRule> downgradeRules;

  factory KillMatrix.fromJson(Map<String, dynamic> json) {
    final hardRaw = json['hard_gates'];
    final downRaw = json['downgrade_rules'];
    final hardList = hardRaw is List ? hardRaw : _defaultHardGatesJson;
    final downList = downRaw is List ? downRaw : _defaultDowngradeRulesJson;
    return KillMatrix(
      version: _string(json['version'], '12.0.0'),
      hardGates: hardList.map((item) => KillGate.fromJson(_asMap(item))).toList(growable: false),
      downgradeRules: downList.map((item) => DowngradeRule.fromJson(_asMap(item))).toList(growable: false),
    );
  }

  KillGate? gateByCode(String code) {
    for (final gate in hardGates) {
      if (gate.code == code) return gate;
    }
    return null;
  }
}

class KillGate {
  const KillGate({
    required this.code,
    required this.nameAr,
    required this.effect,
    required this.severity,
    required this.enabled,
  });

  final String code;
  final String nameAr;
  final String effect;
  final double severity;
  final bool enabled;

  factory KillGate.fromJson(Map<String, dynamic> json) => KillGate(
        code: _string(json['code'], 'UNKNOWN_GATE'),
        nameAr: _string(json['name_ar'] ?? json['label'], 'بوابة رفض'),
        effect: _string(json['effect'], 'REJECT'),
        severity: _normalizedScore(json['severity'] ?? 1.0),
        enabled: _bool(json['enabled'], true),
      );
}

class DowngradeRule {
  const DowngradeRule({
    required this.code,
    required this.nameAr,
    required this.threshold,
    required this.action,
    required this.enabled,
  });

  final String code;
  final String nameAr;
  final double threshold;
  final String action;
  final bool enabled;

  factory DowngradeRule.fromJson(Map<String, dynamic> json) => DowngradeRule(
        code: _string(json['code'], 'UNKNOWN_DOWNGRADE'),
        nameAr: _string(json['name_ar'] ?? json['label'], 'خفض التصنيف'),
        threshold: _double(json['threshold'], 3.0),
        action: _string(json['action'], 'DOWNGRADE'),
        enabled: _bool(json['enabled'], true),
      );
}

Map<String, dynamic> _asMap(dynamic value) {
  if (value is Map<String, dynamic>) return value;
  if (value is Map) return value.map((key, val) => MapEntry(key.toString(), val));
  return <String, dynamic>{};
}

String _string(dynamic value, String fallback) {
  if (value == null) return fallback;
  final text = value.toString().trim();
  return text.isEmpty ? fallback : text;
}

int _int(dynamic value, int fallback) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  if (value is String) return int.tryParse(value.trim()) ?? fallback;
  return fallback;
}

double _double(dynamic value, double fallback) {
  if (value is num) return value.toDouble();
  if (value is String) return double.tryParse(value.trim()) ?? fallback;
  return fallback;
}

double _normalizedScore(dynamic value) {
  final raw = _double(value, 0.0);
  if (raw > 1.0) return (raw / 100.0).clamp(0.0, 1.0).toDouble();
  return raw.clamp(0.0, 1.0).toDouble();
}

bool _bool(dynamic value, bool fallback) {
  if (value is bool) return value;
  if (value is String) {
    final normalized = value.trim().toLowerCase();
    if (normalized == 'true' || normalized == '1' || normalized == 'yes') return true;
    if (normalized == 'false' || normalized == '0' || normalized == 'no') return false;
  }
  if (value is num) return value != 0;
  return fallback;
}

const List<Map<String, dynamic>> _defaultHardGatesJson = <Map<String, dynamic>>[
  <String, dynamic>{
    'code': 'G01_NO_STRUCTURE',
    'name_ar': 'لا توجد بنية جيولوجية حاكمة',
    'effect': 'REJECT',
    'severity': 1.0,
    'enabled': true,
  },
  <String, dynamic>{
    'code': 'G02_NO_PATTERN',
    'name_ar': 'لا يوجد نمط هندسي أو عنقودي داعم',
    'effect': 'REJECT',
    'severity': 1.0,
    'enabled': true,
  },
  <String, dynamic>{
    'code': 'G03_NO_SWIR',
    'name_ar': 'لا توجد بوابة SWIR/Clay/Silica مؤكدة',
    'effect': 'HOLD',
    'severity': 0.7,
    'enabled': true,
  },
  <String, dynamic>{
    'code': 'G04_FEOX_ALONE',
    'name_ar': 'أكسيد الحديد منفرداً غير كافٍ',
    'effect': 'REJECT',
    'severity': 1.0,
    'enabled': true,
  },
  <String, dynamic>{
    'code': 'G05_SPECTRAL_ALONE',
    'name_ar': 'إشارة طيفية بلا بنية أو نمط',
    'effect': 'REJECT',
    'severity': 1.0,
    'enabled': true,
  },
];

const List<Map<String, dynamic>> _defaultDowngradeRulesJson = <Map<String, dynamic>>[
  <String, dynamic>{
    'code': 'D01_ACTIVE_INDICATORS_LT_3',
    'name_ar': 'أقل من 3 مؤشرات نشطة داخل 250 متر',
    'threshold': 3,
    'action': 'DOWNGRADE',
    'enabled': true,
  },
];
