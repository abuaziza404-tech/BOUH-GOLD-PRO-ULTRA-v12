import '../../core/utils/geo_math.dart';
import '../../engines/bouh_supreme_engine.dart';
import '../../engines/gpz_engine.dart';
import '../../engines/similarity_engine.dart';
import '../../engines/spectral_engine.dart';
import '../datasources/local_pack_datasource.dart';

enum TargetSortMode { highestPScore, highestIpi, eliteFirst, nearest }

class CoordinateAnalysisResult {
  const CoordinateAnalysisResult({
    required this.queryLatitude,
    required this.queryLongitude,
    required this.nearestCell,
    required this.distanceMeters,
    required this.spectralMetrics,
    required this.engineResult,
    required this.gpzRecommendation,
    required this.similarityMatch,
    required this.packVersion,
  });

  final double queryLatitude;
  final double queryLongitude;
  final RegionGridCell nearestCell;
  final double distanceMeters;
  final SpectralMetrics spectralMetrics;
  final BouhEngineResult engineResult;
  final GpzRecommendation gpzRecommendation;
  final SimilarityMatch similarityMatch;
  final String packVersion;
}

class TargetPreview {
  const TargetPreview({
    required this.cell,
    required this.spectralMetrics,
    required this.engineResult,
    required this.distanceMeters,
  });

  final RegionGridCell cell;
  final SpectralMetrics spectralMetrics;
  final BouhEngineResult engineResult;
  final double distanceMeters;
}

class AnalysisRepository {
  AnalysisRepository({required LocalPackDataSource localPackDataSource}) : _localPackDataSource = localPackDataSource;

  final LocalPackDataSource _localPackDataSource;
  RegionPackBundle? _cachedPack;
  List<RegionGridCell>? _cachedGridData;

  Future<RegionPackBundle> getPack({bool forceReload = false}) async {
    if (!forceReload && _cachedPack != null) return _cachedPack!;
    final pack = await _localPackDataSource.loadRedSeaHillsPack();
    _cachedPack = pack;
    _cachedGridData = pack.manifest.gridData;
    return pack;
  }

  Future<List<RegionGridCell>> getGridData({bool forceReload = false}) async {
    if (!forceReload && _cachedGridData != null) return _cachedGridData!;
    final pack = await getPack(forceReload: forceReload);
    _cachedGridData = pack.manifest.gridData;
    return _cachedGridData!;
  }

  Future<CoordinateAnalysisResult> analyzeCoordinate({
    required double latitude,
    required double longitude,
    double maxSearchDistanceMeters = 50000.0,
  }) async {
    final pack = await getPack();
    final grid = await getGridData();
    if (grid.isEmpty) {
      throw StateError('Region Pack grid_data is empty. Add precompiled grid cells before field analysis.');
    }

    final nearest = await GeoMath.findNearestCellAsync(
      latitude: latitude,
      longitude: longitude,
      cells: grid.map((cell) => cell.toJson()).toList(growable: false),
      maxDistanceMeters: maxSearchDistanceMeters,
      shortlistSize: 24,
    );

    if (nearest == null) {
      throw StateError('لا توجد خلية Region Pack ضمن نطاق البحث الحالي.');
    }

    final cellJson = nearest.cell;
    final nearestCell = RegionGridCell.fromJson(cellJson);
    final sensorType = SpectralEngine.parseSensorType(nearestCell.sensorType);
    final spectral = SpectralEngine.analyze(bands: nearestCell.bands, sensorType: sensorType);
    final engineResult = BouhSupremeEngine.analyze(
      input: BouhAnalysisInput(
        spectral: spectral,
        structureScore: nearestCell.structureScore,
        patternScore: nearestCell.patternScore,
        fieldEvidenceScore: nearestCell.fieldEvidenceScore,
        activeIndicators250m: nearestCell.activeIndicators250m,
      ),
      killMatrix: pack.killMatrix,
    );
    final gpz = GpzEngine.recommend(
      magneticRisk: nearestCell.magneticRisk,
      quartzIndex: spectral.quartzIndex,
      quartzHigh: spectral.hasQuartzSilica,
    );
    final similarity = SimilarityEngine.bestMatch(
      sampleVector5: spectral.normalizedVector5,
      signatures: pack.manifest.knownSignatures,
    );

    return CoordinateAnalysisResult(
      queryLatitude: latitude,
      queryLongitude: longitude,
      nearestCell: nearestCell,
      distanceMeters: nearest.distanceMeters,
      spectralMetrics: spectral,
      engineResult: engineResult,
      gpzRecommendation: gpz,
      similarityMatch: similarity,
      packVersion: pack.manifest.version,
    );
  }

  Future<List<TargetPreview>> getTargetPreviews({
    TargetSortMode sortMode = TargetSortMode.eliteFirst,
    double? referenceLatitude,
    double? referenceLongitude,
  }) async {
    final pack = await getPack();
    final grid = await getGridData();
    final previews = <TargetPreview>[];

    for (final cell in grid) {
      final spectral = SpectralEngine.analyze(
        bands: cell.bands,
        sensorType: SpectralEngine.parseSensorType(cell.sensorType),
      );
      final engineResult = BouhSupremeEngine.analyze(
        input: BouhAnalysisInput(
          spectral: spectral,
          structureScore: cell.structureScore,
          patternScore: cell.patternScore,
          fieldEvidenceScore: cell.fieldEvidenceScore,
          activeIndicators250m: cell.activeIndicators250m,
        ),
        killMatrix: pack.killMatrix,
      );
      final distance = (referenceLatitude == null || referenceLongitude == null)
          ? double.infinity
          : GeoMath.haversineDistanceMeters(
              lat1: referenceLatitude,
              lon1: referenceLongitude,
              lat2: cell.latitude,
              lon2: cell.longitude,
            );
      previews.add(TargetPreview(
        cell: cell,
        spectralMetrics: spectral,
        engineResult: engineResult,
        distanceMeters: distance,
      ));
    }

    previews.sort((a, b) {
      switch (sortMode) {
        case TargetSortMode.highestPScore:
          return b.engineResult.pScore.compareTo(a.engineResult.pScore);
        case TargetSortMode.highestIpi:
          return b.engineResult.ipi.compareTo(a.engineResult.ipi);
        case TargetSortMode.nearest:
          return a.distanceMeters.compareTo(b.distanceMeters);
        case TargetSortMode.eliteFirst:
          final eliteCompare = _eliteRank(b.engineResult).compareTo(_eliteRank(a.engineResult));
          if (eliteCompare != 0) return eliteCompare;
          return b.engineResult.ipi.compareTo(a.engineResult.ipi);
      }
    });

    return previews;
  }

  int _eliteRank(BouhEngineResult result) {
    if (result.decisionStatus == BouhDecisionStatus.targetBElite) return 4;
    if (result.decisionStatus == BouhDecisionStatus.candidate) return 3;
    if (result.decisionStatus == BouhDecisionStatus.hold) return 2;
    if (result.decisionStatus == BouhDecisionStatus.lowHold) return 1;
    return 0;
  }
}
