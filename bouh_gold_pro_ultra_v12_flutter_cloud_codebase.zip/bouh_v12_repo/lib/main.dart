import 'package:flutter/material.dart';

import 'presentation/screens/map_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BouhGoldProUltraApp());
}

class BouhGoldProUltraApp extends StatelessWidget {
  const BouhGoldProUltraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بوح التضاريس',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFFD700),
          brightness: Brightness.dark,
          primary: const Color(0xFFFFD700),
          surface: const Color(0xFF121212),
        ),
        fontFamily: 'sans',
      ),
      home: const BouhMapScreen(),
    );
  }
}
